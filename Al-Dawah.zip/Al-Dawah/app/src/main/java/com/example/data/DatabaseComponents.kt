package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// ==========================================
// ROOM ENTITIES
// ==========================================

@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "quran", "hadith", "dua"
    val title: String,
    val subtitle: String,
    val referenceId: String,
    val arabicText: String = "",
    val translationText: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasbih_history")
data class TasbihHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dhikrName: String,
    val count: Int,
    val timestamp: Long = System.currentTimeMillis()
)

// ==========================================
// ROOM DAO
// ==========================================

@Dao
interface AppDao {
    // Bookmarks
    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAllBookmarks(): Flow<List<Bookmark>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: Bookmark)

    @Query("DELETE FROM bookmarks WHERE type = :type AND referenceId = :refId")
    suspend fun deleteBookmarkByRef(type: String, refId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE type = :type AND referenceId = :refId LIMIT 1)")
    fun isBookmarked(type: String, refId: String): Flow<Boolean>

    // Notes
    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<Note>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNoteById(id: Int)

    // Tasbih History
    @Query("SELECT * FROM tasbih_history ORDER BY timestamp DESC")
    fun getAllTasbihHistory(): Flow<List<TasbihHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasbihHistory(history: TasbihHistory)

    @Query("DELETE FROM tasbih_history")
    suspend fun clearTasbihHistory()
}

// ==========================================
// ROOM DATABASE
// ==========================================

@Database(entities = [Bookmark::class, Note::class, TasbihHistory::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "imaan_hub_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// ==========================================
// REPOSITORY PATTERN
// ==========================================

class AppRepository(private val appDao: AppDao) {
    val allBookmarks: Flow<List<Bookmark>> = appDao.getAllBookmarks()
    val allNotes: Flow<List<Note>> = appDao.getAllNotes()
    val allTasbihHistory: Flow<List<TasbihHistory>> = appDao.getAllTasbihHistory()

    suspend fun addBookmark(bookmark: Bookmark) = appDao.insertBookmark(bookmark)

    suspend fun removeBookmark(type: String, refId: String) = appDao.deleteBookmarkByRef(type, refId)

    fun checkIfBookmarked(type: String, refId: String): Flow<Boolean> = appDao.isBookmarked(type, refId)

    suspend fun addNote(note: Note) = appDao.insertNote(note)

    suspend fun removeNoteById(id: Int) = appDao.deleteNoteById(id)

    suspend fun addTasbihHistory(history: TasbihHistory) = appDao.insertTasbihHistory(history)

    suspend fun clearHistory() = appDao.clearTasbihHistory()
}
