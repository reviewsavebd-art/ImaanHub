package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Emerald Green & Rich Gold Islamic Palette
val IslamicGreenPrimary = Color(0xFF0D5C34)  // Rich Emerald Green
val IslamicGreenSecondary = Color(0xFF073B20) // Deep Jungle Green
val IslamicGreenLight = Color(0xFFE6F3EC)     // Gentle Green Mist

val GoldPrimary = Color(0xFFD4AF37)           // Premium Satin Gold
val GoldAccent = Color(0xFFF3CD56)            // Bright Shimmering Gold
val GoldMuted = Color(0xFFC5A028)             // Deep Bronze Gold

val CreamWhite = Color(0xFFFAF8F5)            // High-end Antique Cream
val LuxuryDarkBg = Color(0xFF091F14)          // Elegant Jade Black
val LuxuryDarkSurface = Color(0xFF0E291C)     // Emerald Slate Surface
val PremiumGlassBg = Color(0x1F1A422D)        // Semi-transparent deep emerald tint
val SoftGray = Color(0xFFF0F2F1)
val AccentOrange = Color(0xFFE28743)
