package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.media.MediaPlayer
import android.os.Vibrator
import android.os.VibratorManager
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.data.Bookmark
import com.example.data.IslamicData
import com.example.data.Note
import com.example.data.Surah
import com.example.data.TasbihHistory
import com.example.data.Ayah
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

class ImaanHubViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = AppRepository(db.appDao())

    // ----------------------------------------------------
    // PERSISTED STATES (FROM ROOM)
    // ----------------------------------------------------
    val bookmarks: StateFlow<List<Bookmark>> = repository.allBookmarks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Direct binding for backwards compatibility
    val notes: StateFlow<List<Note>> = repository.allNotes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val tasbihHistory: StateFlow<List<TasbihHistory>> = repository.allTasbihHistory.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Helper to query bookmark state of a specific ref
    fun isBookmarked(type: String, refId: String): StateFlow<Boolean> {
        val flow = MutableStateFlow(false)
        viewModelScope.launch {
            repository.checkIfBookmarked(type, refId).collect {
                flow.value = it
            }
        }
        return flow.asStateFlow()
    }

    // ----------------------------------------------------
    // QURAN PLAYER & READING STATES
    // ----------------------------------------------------
    private val _selectedSurah = MutableStateFlow<Surah>(IslamicData.surahs.first())
    val selectedSurah: StateFlow<Surah> = _selectedSurah.asStateFlow()

    private val httpClient = OkHttpClient()
    private val _isSurahLoading = MutableStateFlow(false)
    val isSurahLoading: StateFlow<Boolean> = _isSurahLoading.asStateFlow()

    private val _currentAyahIndex = MutableStateFlow(0)
    val currentAyahIndex: StateFlow<Int> = _currentAyahIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _isAutoScroll = MutableStateFlow(true)
    val isAutoScroll: StateFlow<Boolean> = _isAutoScroll.asStateFlow()

    private val _sleepTimerMinutes = MutableStateFlow(0)
    val sleepTimerMinutes: StateFlow<Int> = _sleepTimerMinutes.asStateFlow()

    private val _quranSearchQuery = MutableStateFlow("")
    val quranSearchQuery: StateFlow<String> = _quranSearchQuery.asStateFlow()

    // ----------------------------------------------------
    // MULTI-QARI (RECITER) SELECTION STATES
    // ----------------------------------------------------
    data class Qari(
        val id: String,
        val name: String,
        val banglaName: String,
        val folder: String
    )

    val qariList = listOf(
        Qari("alafasy", "Mishary Rashid Alafasy", "মিশারি রশিদ আল-আফাসী", "Alafasy_128kbps"),
        Qari("sudais", "Abdurrahman As-Sudais", "আব্দুর রহমান আস-সুদাইস", "Abdurrahmaan_As-Sudais_192kbps"),
        Qari("muaiqly", "Maher Al-Muaiqly", "মাহের আল-মুআইকিলী", "Maher_AlMuaiqly_64kbps"),
        Qari("ghamdi", "Saad Al-Ghamdi", "সাদ আল-গামদি", "Ghamadi_40kbps"),
        Qari("basit", "Abdul Basit Abdus Samad", "আব্দুল বাসেত আব্দুল সামাদ", "Abdul_Basit_Murattal_64kbps"),
        Qari("minshawi", "Muhammad Siddiq Al-Minshawi", "মুহাম্মদ সিদ্দিক আল-মিনশাবি", "Minshawy_Murattal_128kbps")
    )

    private val _selectedQari = MutableStateFlow(qariList.first())
    val selectedQari: StateFlow<Qari> = _selectedQari.asStateFlow()

    fun selectQari(qari: Qari) {
        _selectedQari.value = qari
        if (_isPlaying.value) {
            playAudioForCurrentAyah()
        }
    }

    private var mediaPlayer: MediaPlayer? = null
    private var audioJob: Job? = null
    private var sleepTimerJob: Job? = null

    // ----------------------------------------------------
    // BANGLADESH DISTRICTS & DIVISIONS SELECTION
    // ----------------------------------------------------
    data class BDDistrict(
        val id: String,
        val nameEn: String,
        val nameBn: String,
        val offsetMinutes: Int
    )

    val districtList = listOf(
        BDDistrict("dhaka", "Dhaka", "ঢাকা", 0),
        BDDistrict("rangpur", "Rangpur", "রংপুর", 5),
        BDDistrict("chittagong", "Chittagong", "চট্টগ্রাম", -5),
        BDDistrict("sylhet", "Sylhet", "সিলেট", -6),
        BDDistrict("rajshahi", "Rajshahi", "রাজশাহী", 6),
        BDDistrict("khulna", "Khulna", "খুলনা", 4),
        BDDistrict("barisal", "Barisal", "বরিশাল", 2),
        BDDistrict("mymensingh", "Mymensingh", "ময়মনসিংহ", 1),
        BDDistrict("dinajpur", "Dinajpur", "দিনাজপুর", 6),
        BDDistrict("bogra", "Bogra", "বগুড়া", 4),
        BDDistrict("comilla", "Comilla", "কুমিল্লা", -3),
        BDDistrict("noakhali", "Noakhali", "নোয়াখালী", -3),
        BDDistrict("jessore", "Jessore", "যশোর", 5),
        BDDistrict("faridpur", "Faridpur", "Faridpur", 2),
        BDDistrict("coxsbazar", "Cox's Bazar", "কক্সবাজার", -6),
        BDDistrict("kushtia", "Kushtia", "কুষ্টিয়া", 5)
    )

    private val _selectedDistrict = MutableStateFlow(districtList.first())
    val selectedDistrict: StateFlow<BDDistrict> = _selectedDistrict.asStateFlow()

    fun selectDistrict(district: BDDistrict) {
        _selectedDistrict.value = district
    }

    fun getPrayerTimeForDistrict(prayerName: String, district: BDDistrict = _selectedDistrict.value): String {
        val baseHour: Int
        val baseMin: Int
        when (prayerName) {
            "Fajr" -> { baseHour = 4; baseMin = 45 }
            "Dhuhr" -> { baseHour = 12; baseMin = 30 }
            "Asr" -> { baseHour = 16; baseMin = 45 }
            "Maghrib" -> { baseHour = 18; baseMin = 55 }
            "Isha" -> { baseHour = 20; baseMin = 30 }
            else -> return "00:00"
        }
        
        var totalMin = baseHour * 60 + baseMin + district.offsetMinutes
        if (totalMin < 0) totalMin += 24 * 60
        val finalHour = (totalMin / 60) % 24
        val finalMin = totalMin % 60
        
        val displayHour = if (finalHour % 12 == 0) 12 else finalHour % 12
        val amPm = if (finalHour < 12) "AM" else "PM"
        
        return String.format(Locale.US, "%02d:%02d %s", displayHour, finalMin, amPm)
    }

    private fun createAdjustedSchedule(name: String, baseHour: Int, baseMin: Int, offsetMinutes: Int): PrayerSchedule {
        var totalMin = baseHour * 60 + baseMin + offsetMinutes
        if (totalMin < 0) totalMin += 24 * 60
        val finalHour = (totalMin / 60) % 24
        val finalMin = totalMin % 60
        return PrayerSchedule(name, finalHour, finalMin)
    }

    // ----------------------------------------------------
    // PRAYER TIMES & COMPASS STATES
    // ----------------------------------------------------
    private val _nextPrayerCountdown = MutableStateFlow("00:00:00")
    val nextPrayerCountdown: StateFlow<String> = _nextPrayerCountdown.asStateFlow()

    private val _nextPrayerName = MutableStateFlow("Fajr")
    val nextPrayerName: StateFlow<String> = _nextPrayerName.asStateFlow()

    private val _qiblaRotation = MutableStateFlow(0f)
    val qiblaRotation: StateFlow<Float> = _qiblaRotation.asStateFlow()

    private val _isAzanEnabled = MutableStateFlow(
        mapOf("Fajr" to true, "Dhuhr" to true, "Asr" to true, "Maghrib" to true, "Isha" to true)
    )
    val isAzanEnabled: StateFlow<Map<String, Boolean>> = _isAzanEnabled.asStateFlow()

    // ----------------------------------------------------
    // TASBIH COUNTER STATES
    // ----------------------------------------------------
    private val _tasbihCount = MutableStateFlow(0)
    val tasbihCount: StateFlow<Int> = _tasbihCount.asStateFlow()

    val dhikrList = listOf(
        "SubhanAllah (سبحان الله)",
        "Alhamdulillah (الحمد لله)",
        "Allahu Akbar (الله أكبر)",
        "La ilaha illallah (لا إله إلا الله)",
        "Astaghfirullah (أستغفر الله)"
    )
    private val _selectedDhikr = MutableStateFlow(dhikrList.first())
    val selectedDhikr: StateFlow<String> = _selectedDhikr.asStateFlow()

    private val _isVibrationOn = MutableStateFlow(true)
    val isVibrationOn: StateFlow<Boolean> = _isVibrationOn.asStateFlow()

    private val _isSoundOn = MutableStateFlow(true)
    val isSoundOn: StateFlow<Boolean> = _isSoundOn.asStateFlow()

    // ----------------------------------------------------
    // HADITH SCREEN STATES
    // ----------------------------------------------------
    private val _selectedHadithBook = MutableStateFlow("All")
    val selectedHadithBook: StateFlow<String> = _selectedHadithBook.asStateFlow()

    private val _hadithSearchQuery = MutableStateFlow("")
    val hadithSearchQuery: StateFlow<String> = _hadithSearchQuery.asStateFlow()

    // ----------------------------------------------------
    // DUA SCREEN STATES
    // ----------------------------------------------------
    private val _selectedDuaCategory = MutableStateFlow("Morning")
    val selectedDuaCategory: StateFlow<String> = _selectedDuaCategory.asStateFlow()

    private val _duaSearchQuery = MutableStateFlow("")
    val duaSearchQuery: StateFlow<String> = _duaSearchQuery.asStateFlow()

    // ----------------------------------------------------
    // ISLAMIC BOOKS STATE
    // ----------------------------------------------------
    private val _selectedBookId = MutableStateFlow<Int?>(null)
    val selectedBookId: StateFlow<Int?> = _selectedBookId.asStateFlow()

    // ----------------------------------------------------
    // ISLAMIC QUIZ STATE
    // ----------------------------------------------------
    private val _currentQuestionIndex = MutableStateFlow(0)
    val currentQuestionIndex: StateFlow<Int> = _currentQuestionIndex.asStateFlow()

    private val _quizSelectedAnswer = MutableStateFlow<Int?>(null)
    val quizSelectedAnswer: StateFlow<Int?> = _quizSelectedAnswer.asStateFlow()

    private val _quizScore = MutableStateFlow(0)
    val quizScore: StateFlow<Int> = _quizScore.asStateFlow()

    private val _isQuizAnswered = MutableStateFlow(false)
    val isQuizAnswered: StateFlow<Boolean> = _isQuizAnswered.asStateFlow()

    // ----------------------------------------------------
    // ZAKAT CALCULATOR STATES
    // ----------------------------------------------------
    private val _zakatCash = MutableStateFlow("")
    val zakatCash: StateFlow<String> = _zakatCash.asStateFlow()

    private val _zakatGold = MutableStateFlow("")
    val zakatGold: StateFlow<String> = _zakatGold.asStateFlow()

    private val _zakatSilver = MutableStateFlow("")
    val zakatSilver: StateFlow<String> = _zakatSilver.asStateFlow()

    private val _zakatAssets = MutableStateFlow("")
    val zakatAssets: StateFlow<String> = _zakatAssets.asStateFlow()

    private val _zakatLiabilities = MutableStateFlow("")
    val zakatLiabilities: StateFlow<String> = _zakatLiabilities.asStateFlow()

    private val _zakatResult = MutableStateFlow(0.0)
    val zakatResult: StateFlow<Double> = _zakatResult.asStateFlow()

    // ----------------------------------------------------
    // MOSQUE FINDER STATE
    // ----------------------------------------------------
    private val _mosqueSearchQuery = MutableStateFlow("")
    val mosqueSearchQuery: StateFlow<String> = _mosqueSearchQuery.asStateFlow()

    val simulatedMosques = listOf(
        SimulatedMosque("Baitul Mukarram National Mosque", "Central Dhaka, Bangladesh", 0.8, "4:30 AM", "12:15 PM", "4:45 PM", "6:50 PM", "8:15 PM"),
        SimulatedMosque("Imaan Center Mosque", "Avenue Road, Premium Square", 1.5, "4:32 AM", "12:15 PM", "4:46 PM", "6:52 PM", "8:17 PM"),
        SimulatedMosque("Al-Noor Islamic Center", "Gold Street, Luxury District", 2.4, "4:30 AM", "12:15 PM", "4:45 PM", "6:50 PM", "8:15 PM"),
        SimulatedMosque("Masjid Al-Aqsa Community Dome", "North Green Way", 4.1, "4:35 AM", "12:20 PM", "4:50 PM", "6:55 PM", "8:20 PM")
    )

    data class SimulatedMosque(
        val name: String,
        val address: String,
        val distanceKm: Double,
        val fajr: String,
        val dhuhr: String,
        val asr: String,
        val maghrib: String,
        val isha: String
    )

    // ----------------------------------------------------
    // SETTINGS STATES
    // ----------------------------------------------------
    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _fontSizeMultiplier = MutableStateFlow(1.0f) // 0.8f (Small), 1.0f (Medium), 1.2f (Large)
    val fontSizeMultiplier: StateFlow<Float> = _fontSizeMultiplier.asStateFlow()

    private val _selectedArabicFont = MutableStateFlow("KFGQPC Uthman Taha")
    val selectedArabicFont: StateFlow<String> = _selectedArabicFont.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("English")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    // ----------------------------------------------------
    // INITIALIZATION
    // ----------------------------------------------------
    init {
        startPrayerCountdown()
        startQiblaSimulation()
    }

    // ----------------------------------------------------
    // QURAN PLAYER ACTIONS
    // ----------------------------------------------------
    fun fetchSurahOnline(surahNumber: Int) {
        if (surahNumber in listOf(1, 108, 112, 113, 114, 36)) {
            // Preloaded with maximum details offline beautifully
            return
        }
        viewModelScope.launch {
            _isSurahLoading.value = true
            try {
                val url = "https://api.alquran.cloud/v1/surah/$surahNumber/editions/quran-simple-clean,bn.bengali,en.sahih"
                val responseText = withContext(Dispatchers.IO) {
                    val request = Request.Builder().url(url).build()
                    httpClient.newCall(request).execute().use { response ->
                        if (response.isSuccessful) response.body?.string() else null
                    }
                }

                if (responseText != null) {
                    val json = JSONObject(responseText)
                    val dataArray = json.getJSONArray("data")
                    
                    val arabicEdition = dataArray.getJSONObject(0)
                    val arabicAyahs = arabicEdition.getJSONArray("ayahs")
                    
                    val banglaEdition = dataArray.getJSONObject(1)
                    val banglaAyahs = banglaEdition.getJSONArray("ayahs")
                    
                    val englishEdition = dataArray.getJSONObject(2)
                    val englishAyahs = englishEdition.getJSONArray("ayahs")
                    
                    val parsedAyahs = mutableListOf<com.example.data.Ayah>()
                    for (i in 0 until arabicAyahs.length()) {
                        val arObj = arabicAyahs.getJSONObject(i)
                        val bnObj = banglaAyahs.getJSONObject(i)
                        val enObj = englishAyahs.getJSONObject(i)
                        
                        parsedAyahs.add(
                            com.example.data.Ayah(
                                numberInSurah = arObj.getInt("numberInSurah"),
                                arabic = arObj.getString("text"),
                                english = enObj.getString("text"),
                                bangla = bnObj.getString("text")
                            )
                        )
                    }
                    
                    val currentSurah = _selectedSurah.value
                    if (currentSurah.number == surahNumber && parsedAyahs.isNotEmpty()) {
                        _selectedSurah.value = currentSurah.copy(ayahs = parsedAyahs)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isSurahLoading.value = false
            }
        }
    }

    fun selectSurah(surah: Surah) {
        _selectedSurah.value = surah
        _currentAyahIndex.value = 0
        stopAudio()
        fetchSurahOnline(surah.number)
    }

    fun selectAyah(index: Int) {
        if (index in 0 until _selectedSurah.value.ayahs.size) {
            _currentAyahIndex.value = index
            if (_isPlaying.value) {
                playAudioForCurrentAyah()
            }
        }
    }

    fun togglePlayPause() {
        if (_isPlaying.value) {
            stopAudio()
        } else {
            _isPlaying.value = true
            playAudioForCurrentAyah()
        }
    }

    private fun playAudioForCurrentAyah() {
        audioJob?.cancel()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaPlayer = null

        audioJob = viewModelScope.launch {
            val currentAyah = _selectedSurah.value.ayahs[_currentAyahIndex.value]
            val surahStr = String.format(Locale.US, "%03d", _selectedSurah.value.number)
            val ayahStr = String.format(Locale.US, "%03d", currentAyah.numberInSurah)
            val url = "https://www.everyayah.com/data/${_selectedQari.value.folder}/$surahStr$ayahStr.mp3"

            var streamSuccess = false
            try {
                val mPlayer = MediaPlayer()
                mediaPlayer = mPlayer
                withContext(Dispatchers.IO) {
                    mPlayer.setDataSource(url)
                    mPlayer.prepare()
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    mPlayer.playbackParams = mPlayer.playbackParams.setSpeed(_playbackSpeed.value)
                }
                mPlayer.start()
                _isPlaying.value = true
                streamSuccess = true

                var isCompleted = false
                mPlayer.setOnCompletionListener {
                    isCompleted = true
                    viewModelScope.launch {
                        if (_isPlaying.value) {
                            if (_currentAyahIndex.value < _selectedSurah.value.ayahs.size - 1) {
                                _currentAyahIndex.value += 1
                                playAudioForCurrentAyah()
                            } else {
                                _isPlaying.value = false
                                _currentAyahIndex.value = 0
                            }
                        }
                    }
                }

                // Wait until the audio completes playing
                while (!isCompleted && _isPlaying.value && mediaPlayer == mPlayer) {
                    delay(100)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Fallback to simulation if internet is offline or any error occurs
            if (!streamSuccess && _isPlaying.value) {
                // Words take approx 600ms to recite, plus some baseline
                val baseTimeMs = 2000L
                val wordTimeMs = currentAyah.arabic.split(" ").size * 450L
                val duration = ((baseTimeMs + wordTimeMs) / _playbackSpeed.value).toLong()
                delay(duration)

                if (_isPlaying.value) {
                    if (_currentAyahIndex.value < _selectedSurah.value.ayahs.size - 1) {
                        _currentAyahIndex.value += 1
                        playAudioForCurrentAyah()
                    } else {
                        _isPlaying.value = false
                        _currentAyahIndex.value = 0
                    }
                }
            }
        }
    }

    fun stopAudio() {
        _isPlaying.value = false
        audioJob?.cancel()
        audioJob = null
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaPlayer = null
    }

    fun nextAyah() {
        if (_currentAyahIndex.value < _selectedSurah.value.ayahs.size - 1) {
            _currentAyahIndex.value += 1
            if (_isPlaying.value) playAudioForCurrentAyah()
        }
    }

    fun prevAyah() {
        if (_currentAyahIndex.value > 0) {
            _currentAyahIndex.value -= 1
            if (_isPlaying.value) playAudioForCurrentAyah()
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        if (_isPlaying.value) playAudioForCurrentAyah()
    }

    fun toggleAutoScroll() {
        _isAutoScroll.value = !_isAutoScroll.value
    }

    fun setSleepTimer(minutes: Int) {
        _sleepTimerMinutes.value = minutes
        sleepTimerJob?.cancel()
        if (minutes > 0) {
            sleepTimerJob = viewModelScope.launch {
                delay(minutes * 60 * 1000L)
                stopAudio()
                _sleepTimerMinutes.value = 0
            }
        }
    }

    fun setQuranSearchQuery(query: String) {
        _quranSearchQuery.value = query
    }

    // ----------------------------------------------------
    // BOOKMARKS ACTIONS
    // ----------------------------------------------------
    fun toggleBookmark(type: String, title: String, subtitle: String, refId: String, arabicText: String = "", translationText: String = "") {
        viewModelScope.launch {
            repository.checkIfBookmarked(type, refId).collect { alreadyBookmarked ->
                if (alreadyBookmarked) {
                    repository.removeBookmark(type, refId)
                } else {
                    repository.addBookmark(
                        Bookmark(
                            type = type,
                            title = title,
                            subtitle = subtitle,
                            referenceId = refId,
                            arabicText = arabicText,
                            translationText = translationText
                        )
                    )
                }
                // Stop collecting immediately after first check to prevent loop
                return@collect
            }
        }
    }

    // ----------------------------------------------------
    // HADITH ACTIONS
    // ----------------------------------------------------
    fun selectHadithBook(book: String) {
        _selectedHadithBook.value = book
    }

    fun setHadithSearchQuery(query: String) {
        _hadithSearchQuery.value = query
    }

    // ----------------------------------------------------
    // DUA ACTIONS
    // ----------------------------------------------------
    fun selectDuaCategory(category: String) {
        _selectedDuaCategory.value = category
    }

    fun setDuaSearchQuery(query: String) {
        _duaSearchQuery.value = query
    }

    // ----------------------------------------------------
    // TASBIH ACTIONS
    // ----------------------------------------------------
    fun incrementTasbih() {
        _tasbihCount.value += 1
        triggerHapticFeedback()
    }

    fun resetTasbih() {
        if (_tasbihCount.value > 0) {
            val dhikr = _selectedDhikr.value
            val currentVal = _tasbihCount.value
            viewModelScope.launch {
                repository.addTasbihHistory(TasbihHistory(dhikrName = dhikr, count = currentVal))
            }
        }
        _tasbihCount.value = 0
    }

    fun selectDhikr(dhikr: String) {
        resetTasbih()
        _selectedDhikr.value = dhikr
    }

    fun toggleVibration() {
        _isVibrationOn.value = !_isVibrationOn.value
    }

    fun toggleSound() {
        _isSoundOn.value = !_isSoundOn.value
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    private fun triggerHapticFeedback() {
        if (!_isVibrationOn.value) return
        viewModelScope.launch {
            try {
                val context = getApplication<Application>().applicationContext
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                    val vibrator = vibratorManager?.defaultVibrator
                    vibrator?.vibrate(android.os.VibrationEffect.createOneShot(50, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(50)
                }
            } catch (e: Exception) {
                // Silently ignore if no permission or unavailable
            }
        }
    }

    // ----------------------------------------------------
    // PRAYER TIMES ENGINE
    // ----------------------------------------------------
    private fun startPrayerCountdown() {
        viewModelScope.launch {
            while (true) {
                val cal = Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Dhaka"))
                val hour = cal.get(Calendar.HOUR_OF_DAY)
                val min = cal.get(Calendar.MINUTE)
                val sec = cal.get(Calendar.SECOND)

                // Define prayer schedules dynamically adjusted by selected district offset
                val offset = _selectedDistrict.value.offsetMinutes
                val schedule = listOf(
                    createAdjustedSchedule("Fajr", 4, 45, offset),
                    createAdjustedSchedule("Dhuhr", 12, 30, offset),
                    createAdjustedSchedule("Asr", 16, 45, offset),
                    createAdjustedSchedule("Maghrib", 18, 55, offset),
                    createAdjustedSchedule("Isha", 20, 30, offset)
                )

                var next = schedule.first()
                var diffSeconds = 0L

                val currentSecondsOfDay = hour * 3600 + min * 60 + sec

                for (p in schedule) {
                    val pSeconds = p.hour * 3600 + p.minute * 60
                    if (pSeconds > currentSecondsOfDay) {
                        next = p
                        diffSeconds = (pSeconds - currentSecondsOfDay).toLong()
                        break
                    }
                }

                // If none of the prayer times are in the future for today, the next prayer is Fajr tomorrow
                if (diffSeconds == 0L) {
                    next = schedule.first()
                    val secondsUntilEndOfDay = 24 * 3600 - currentSecondsOfDay
                    val fajrSeconds = next.hour * 3600 + next.minute * 60
                    diffSeconds = (secondsUntilEndOfDay + fajrSeconds).toLong()
                }

                _nextPrayerName.value = next.name

                val h = diffSeconds / 3600
                val m = (diffSeconds % 3600) / 60
                val s = diffSeconds % 60
                _nextPrayerCountdown.value = String.format("%02d:%02d:%02d", h, m, s)

                delay(1000L)
            }
        }
    }

    private data class PrayerSchedule(val name: String, val hour: Int, val minute: Int)

    fun toggleAzan(prayerName: String) {
        val current = _isAzanEnabled.value.toMutableMap()
        current[prayerName] = !(current[prayerName] ?: true)
        _isAzanEnabled.value = current
    }

    private fun startQiblaSimulation() {
        viewModelScope.launch {
            // Gently oscillate Qibla direction representing gyroscope precision
            var angle = 135f // Mecca angle from Bangladesh/South Asia approx
            var direction = 1
            while (true) {
                delay(150L)
                angle += (Math.random() * 0.4f * direction).toFloat()
                if (angle > 137f) direction = -1
                if (angle < 133f) direction = 1
                _qiblaRotation.value = angle
            }
        }
    }

    // ----------------------------------------------------
    // QUIZ ACTIONS
    // ----------------------------------------------------
    fun selectQuizAnswer(index: Int) {
        if (!_isQuizAnswered.value) {
            _quizSelectedAnswer.value = index
            _isQuizAnswered.value = true
            if (index == IslamicData.quizQuestions[_currentQuestionIndex.value].correctAnswerIndex) {
                _quizScore.value += 1
            }
        }
    }

    fun nextQuizQuestion() {
        if (_currentQuestionIndex.value < IslamicData.quizQuestions.size - 1) {
            _currentQuestionIndex.value += 1
            _quizSelectedAnswer.value = null
            _isQuizAnswered.value = false
        } else {
            // Loop / Reset Quiz
            _currentQuestionIndex.value = 0
            _quizSelectedAnswer.value = null
            _isQuizAnswered.value = false
            _quizScore.value = 0
        }
    }

    // ----------------------------------------------------
    // ZAKAT ACTIONS
    // ----------------------------------------------------
    fun updateZakatCash(valStr: String) { _zakatCash.value = valStr; calculateZakat() }
    fun updateZakatGold(valStr: String) { _zakatGold.value = valStr; calculateZakat() }
    fun updateZakatSilver(valStr: String) { _zakatSilver.value = valStr; calculateZakat() }
    fun updateZakatAssets(valStr: String) { _zakatAssets.value = valStr; calculateZakat() }
    fun updateZakatLiabilities(valStr: String) { _zakatLiabilities.value = valStr; calculateZakat() }

    private fun calculateZakat() {
        val cash = _zakatCash.value.toDoubleOrNull() ?: 0.0
        val gold = (_zakatGold.value.toDoubleOrNull() ?: 0.0) * 85.0 // gold value factor
        val silver = (_zakatSilver.value.toDoubleOrNull() ?: 0.0) * 12.0 // silver value factor
        val assets = _zakatAssets.value.toDoubleOrNull() ?: 0.0
        val liabilities = _zakatLiabilities.value.toDoubleOrNull() ?: 0.0

        val totalWealth = cash + gold + silver + assets - liabilities
        val nisabThreshold = 85000.0 // approx standard 85g gold Nisab value in local unit/currency equivalent
        if (totalWealth >= nisabThreshold) {
            _zakatResult.value = totalWealth * 0.025 // 2.5% standard Zakat rate
        } else {
            _zakatResult.value = 0.0
        }
    }

    // ----------------------------------------------------
    // MOSQUE ACTIONS
    // ----------------------------------------------------
    fun setMosqueSearchQuery(query: String) {
        _mosqueSearchQuery.value = query
    }

    // ----------------------------------------------------
    // NOTES ACTIONS (ROOM WRAPPERS WITH MATCHING NAMES)
    // ----------------------------------------------------
    fun saveNote(title: String, content: String) {
        if (title.isBlank() && content.isBlank()) return
        viewModelScope.launch {
            repository.addNote(Note(title = title, content = content))
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.removeNoteById(note.id)
        }
    }

    // ----------------------------------------------------
    // SETTINGS ACTIONS
    // ----------------------------------------------------
    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun setFontSizeMultiplier(multiplier: Float) {
        _fontSizeMultiplier.value = multiplier
    }

    fun selectArabicFont(font: String) {
        _selectedArabicFont.value = font
    }

    fun selectLanguage(lang: String) {
        _selectedLanguage.value = lang
    }

    fun selectBook(id: Int?) {
        _selectedBookId.value = id
    }

    override fun onCleared() {
        super.onCleared()
        stopAudio()
    }
}
