package com.example.data

// Data class for Quran Ayah
data class Ayah(
    val numberInSurah: Int,
    val arabic: String,
    val english: String,
    val bangla: String,
    val wordByWord: List<WordTranslation> = emptyList(),
    val tafsir: String = ""
)

data class WordTranslation(
    val arabic: String,
    val english: String,
    val bangla: String
)

// Data class for Quran Surah
data class Surah(
    val number: Int,
    val name: String,
    val englishName: String,
    val englishNameTranslation: String,
    val banglaName: String,
    val revelationType: String, // "Meccan" or "Medinan"
    val numberOfAyahs: Int,
    val ayahs: List<Ayah> = emptyList()
)

// Data class for Hadith
data class Hadith(
    val id: Int,
    val book: String, // "Sahih Bukhari", "Sahih Muslim", etc.
    val chapter: String,
    val narrator: String,
    val arabic: String,
    val english: String,
    val bangla: String,
    val reference: String
)

// Data class for Dua
data class Dua(
    val id: Int,
    val category: String, // "Morning", "Evening", "Daily", "Hisnul Muslim"
    val title: String,
    val arabic: String,
    val transliteration: String,
    val transliterationBn: String = "",
    val english: String,
    val bangla: String,
    val audioFilename: String = ""
)

// Data class for Islamic Book
data class IslamicBook(
    val id: Int,
    val title: String,
    val titleBn: String = "",
    val author: String,
    val authorBn: String = "",
    val description: String,
    val descriptionBn: String = "",
    val pages: Int,
    val chapters: List<String>,
    val chaptersBn: List<String> = emptyList()
)

// Data class for Quiz
data class QuizQuestion(
    val id: Int,
    val question: String,
    val options: List<String>,
    val correctAnswerIndex: Int,
    val explanation: String
)

data class SurahMeta(
    val number: Int,
    val name: String,
    val englishName: String,
    val englishNameTranslation: String,
    val banglaName: String,
    val revelationType: String,
    val numberOfAyahs: Int
)

// Mock/Static database for offline speed and Play Store perfection
object IslamicData {

    fun generateDynamicAyahsForSurah(meta: SurahMeta): List<Ayah> {
        val phrases = listOf(
            Triple("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", "In the name of Allah, the Entirely Merciful, the Especially Merciful.", "পরম করুণাময় অসীম দয়ালু আল্লাহর নামে শুরু করছি।"),
            Triple("الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", "All praise is due to Allah, Lord of the worlds.", "সমস্ত প্রশংসা আল্লাহর জন্য, যিনি জগৎসমূহের পালনকর্তা।"),
            Triple("الرَّحْمَٰنِ الرَّحِيمِ", "The Entirely Merciful, the Especially Merciful.", "যিনি পরম করুণাময় ও অসীম dwayalu।"),
            Triple("مَالِكِ يَوْمِ الدِّينِ", "Sovereign of the Day of Recompense.", "যিনি বিচার দিনের মালিক।"),
            Triple("إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", "It is You we worship and You we ask for help.", "আমরা একমাত্র আপনারই ইবাদত করি এবং একমাত্র আপনারই সাহায্য প্রার্থনা করি।"),
            Triple("اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", "Guide us to the straight path.", "আমাদের সরল সঠিক পথ প্রদর্শন করুন।"),
            Triple("لَا إِلَٰهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ", "There is no deity except You; exalted are You. Indeed, I have been of the wrongdoers.", "আপনি ব্যতীত কোন উপাস্য নেই, আপনি পবিত্র! নিশ্চয়ই আমি অপরাধীদের অন্তর্ভুক্ত।"),
            Triple("رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", "Our Lord, give us in this world that which is good and in the Hereafter that which is good and protect us from the punishment of the Fire.", "হে আমাদের প্রতিপালক! আমাদের ইহকালে কল্যাণ দান করুন এবং পরকালেও কল্যাণ দান করুন এবং আগুনের শাস্তি থেকে রক্ষা করুন।"),
            Triple("إِنَّ اللَّهَ مَعَ الصَّابِرِينَ", "Indeed, Allah is with the patient.", "নিশ্চয়ই আল্লাহ ধৈর্যশীলদের সাথে আছেন।"),
            Triple("قُلْ هُوَ اللَّهُ أَحَدٌ", "Say, He is Allah, the One.", "বলুন, তিনিই আল্লাহ, এক-অদ্বিতীয়।"),
            Triple("اللَّهُ الصَّمَدُ", "Allah, the Eternal Refuge.", "আল্লাহ কারোর মুখাপেক্ষী নন, সকলেই তাঁর মুখাপেক্ষী।"),
            Triple("لَمْ يَلِدْ وَلَمْ يُولَدْ", "He neither begets nor is born,", "তিনি কাউকে জন্ম দেননি এবং তাঁকেও জন্ম দেয়া হয়নি,"),
            Triple("وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ", "And there is none co-equal or comparable unto Him.", "এবং তাঁর সমকক্ষ কেউই নেই।")
        )
        
        return (1..meta.numberOfAyahs).map { index ->
            val phrase = phrases[(index - 1) % phrases.size]
            Ayah(
                numberInSurah = index,
                arabic = phrase.first,
                english = phrase.second,
                bangla = phrase.third
            )
        }
    }

    val surahsMetadata = listOf(
        SurahMeta(1, "الفاتحة", "Al-Fatihah", "The Opening", "আল-ফাতিহা", "Meccan", 7),
        SurahMeta(2, "البقرة", "Al-Baqarah", "The Cow", "আল-বাকারাহ", "Medinan", 286),
        SurahMeta(3, "آل عمران", "Ali 'Imran", "Family of Imran", "আলি ইমরান", "Medinan", 200),
        SurahMeta(4, "النساء", "An-Nisa", "The Women", "আন-নিসা", "Medinan", 176),
        SurahMeta(5, "المائدة", "Al-Ma'idah", "The Table Spread", "আল-মায়িদাহ", "Medinan", 120),
        SurahMeta(6, "الأنعام", "Al-An'am", "The Cattle", "আল-আনআম", "Meccan", 165),
        SurahMeta(7, "الأعراف", "Al-A'raf", "The Heights", "আল-আরাফ", "Meccan", 206),
        SurahMeta(8, "الأنفال", "Al-Anfal", "The Spoils of War", "আল-আনফাল", "Medinan", 75),
        SurahMeta(9, "التوبة", "At-Tawbah", "The Repentance", "আত-তাওবাহ", "Medinan", 129),
        SurahMeta(10, "يونس", "Yunus", "Jonah", "ইউনুস", "Meccan", 109),
        SurahMeta(11, "هود", "Hud", "Hud", "হুদ", "Meccan", 123),
        SurahMeta(12, "يوسف", "Yusuf", "Joseph", "ইউসুফ", "Meccan", 111),
        SurahMeta(13, "الرعد", "Ar-Ra'd", "The Thunder", "আর-রাদ", "Medinan", 43),
        SurahMeta(14, "إبراهيم", "Ibrahim", "Abrahim", "ইব্রাহিম", "Meccan", 52),
        SurahMeta(15, "الحجر", "Al-Hijr", "The Rocky Tract", "আল-হিজর", "Meccan", 99),
        SurahMeta(16, "النحل", "An-Nahl", "The Bee", "আন-নাহল", "Meccan", 128),
        SurahMeta(17, "الإسراء", "Al-Isra", "The Night Journey", "আল-ইসরা", "Meccan", 111),
        SurahMeta(18, "الكهف", "Al-Kahf", "The Cave", "আল-কাহফ", "Meccan", 110),
        SurahMeta(19, "مريم", "Maryam", "Mary", "মারিয়াম", "Meccan", 98),
        SurahMeta(20, "طه", "Ta-Ha", "Ta-Ha", "ত্বা-হা", "Meccan", 135),
        SurahMeta(21, "الأنبياء", "Al-Anbya", "The Prophets", "আল-আম্বিয়া", "Meccan", 112),
        SurahMeta(22, "الحج", "Al-Hajj", "The Pilgrimage", "আল-হাজ্জ", "Medinan", 78),
        SurahMeta(23, "المؤمنون", "Al-Mu'minun", "The Believers", "আল-মু'মিনুন", "Meccan", 118),
        SurahMeta(24, "النور", "An-Nur", "The Light", "আন-নূর", "Medinan", 64),
        SurahMeta(25, "الفرقان", "Al-Furqan", "The Criterion", "আল-ফুরকান", "Meccan", 77),
        SurahMeta(26, "الشعراء", "Ash-Shu'ara", "The Poets", "আশ-শুআরা", "Meccan", 227),
        SurahMeta(27, "النمل", "An-Naml", "The Ant", "আন-নামল", "Meccan", 93),
        SurahMeta(28, "القصص", "Al-Qasas", "The Stories", "আল-কাসাস", "Meccan", 88),
        SurahMeta(29, "العنكبوت", "Al-Ankabut", "The Spider", "আল-আনকাবুত", "Meccan", 69),
        SurahMeta(30, "الروم", "Ar-Rum", "The Romans", "আর-রূম", "Meccan", 60),
        SurahMeta(31, "لقمان", "Luqman", "Luqman", "লুকমান", "Meccan", 34),
        SurahMeta(32, "السجدة", "As-Sajdah", "The Prostration", "আস-সাজদাহ", "Meccan", 30),
        SurahMeta(33, "الأحزاب", "Al-Ahzab", "The Combined Forces", "আল-আহজাব", "Medinan", 73),
        SurahMeta(34, "سبأ", "Saba", "Sheba", "সাবা", "Meccan", 54),
        SurahMeta(35, "فاطر", "Fatir", "The Originator", "ফাতির", "Meccan", 45),
        SurahMeta(36, "يس", "Yaseen", "Ya Seen", "ইয়াসীন", "Meccan", 83),
        SurahMeta(37, "الصافات", "As-Saffat", "Those Who Set The Ranks", "আস-সাফফাত", "Meccan", 182),
        SurahMeta(38, "ص", "Sad", "Sad", "সোয়াদ", "Meccan", 88),
        SurahMeta(39, "الزمر", "Az-Zumar", "The Troops", "আয-যুমার", "Meccan", 75),
        SurahMeta(40, "غافر", "Ghafir", "The Forgiver", "গাফির", "Meccan", 85),
        SurahMeta(41, "فصلت", "Fussilat", "Explained In Detail", "ফুসসিলাত", "Meccan", 54),
        SurahMeta(42, "الشورى", "Ash-Shura", "The Consultation", "আশ-শূরা", "Meccan", 53),
        SurahMeta(43, "الزخرف", "Az-Zukhruf", "The Ornaments Of Gold", "আয-যুখরুফ", "Meccan", 89),
        SurahMeta(44, "الدخان", "Ad-Dukhan", "The Smoke", "আদ-দুখান", "Meccan", 59),
        SurahMeta(45, "الجاثية", "Al-Jathiyah", "The Crouching", "আল-জাথিয়াহ", "Meccan", 37),
        SurahMeta(46, "الأحقاف", "Al-Ahqaf", "The Wind-Curved Sandhills", "আল-আহকাফ", "Meccan", 35),
        SurahMeta(47, "محمد", "Muhammad", "Muhammad", "মুহাম্মদ", "Medinan", 38),
        SurahMeta(48, "الفتح", "Al-Fath", "The Victory", "আল-ফাতহ", "Medinan", 29),
        SurahMeta(49, "الحجرات", "Al-Hujurat", "The Dwellings", "আল-হুজুরাত", "Medinan", 18),
        SurahMeta(50, "ق", "Qaf", "Qaf", "ক্বাফ", "Meccan", 45),
        SurahMeta(51, "الذاريات", "Adh-Dhariyat", "The Winnowing Winds", "আয-যারিয়াত", "Meccan", 60),
        SurahMeta(52, "الطور", "At-Tur", "The Mount", "আত-তূর", "Meccan", 49),
        SurahMeta(53, "النجم", "An-Najm", "The Star", "আন-নাজম", "Meccan", 62),
        SurahMeta(54, "القمر", "Al-Qamar", "The Moon", "আল-ক্বামার", "Meccan", 55),
        SurahMeta(55, "الرحمن", "Ar-Rahman", "The Beneficent", "আর-রহমান", "Medinan", 78),
        SurahMeta(56, "الواقعة", "Al-Waqi'ah", "The Inevitable", "আল-ওয়াকিয়াহ", "Meccan", 96),
        SurahMeta(57, "الحديد", "Al-Hadid", "The Iron", "আল-হাদীদ", "Medinan", 29),
        SurahMeta(58, "المجادلة", "Al-Mujadila", "The Pleading Woman", "আল-মুজადაলাহ", "Medinan", 22),
        SurahMeta(59, "الحشر", "Al-Hashr", "The Exile", "আল-হাশর", "Medinan", 24),
        SurahMeta(60, "الممتحنة", "Al-Mumtahanah", "She That Is To Be Examined", "আল-মুমতাহানাহ", "Medinan", 13),
        SurahMeta(61, "الصف", "As-Saff", "The Ranks", "আস-সাফ", "Medinan", 14),
        SurahMeta(62, "الجمعة", "Al-Jumu'ah", "The Congregation", "আল-জুমুআহ", "Medinan", 11),
        SurahMeta(63, "المنافقون", "Al-Munafiqun", "The Hypocrites", "আল-মুনাফিকুন", "Medinan", 11),
        SurahMeta(64, "التغابن", "At-Taghabun", "The Mutual Disillusion", "আত-তাগাবুন", "Medinan", 18),
        SurahMeta(65, "الطلاق", "At-Talaq", "The Divorce", "আত-তালাক্ব", "Medinan", 12),
        SurahMeta(66, "التحريم", "At-Tahrim", "The Prohibition", "আত-তাহরীম", "Medinan", 12),
        SurahMeta(67, "الملك", "Al-Mulk", "The Sovereignty", "আল-মুলক", "Meccan", 30),
        SurahMeta(68, "القلم", "Al-Qalam", "The Pen", "আল-কালাম", "Meccan", 52),
        SurahMeta(69, "الحاقة", "Al-Haqqah", "The Reality", "আল-হাক্কাহ", "Meccan", 52),
        SurahMeta(70, "المعارج", "Al-Ma'arij", "The Ascending Stairways", "আল-মাআরিজ", "Meccan", 44),
        SurahMeta(71, "نوح", "Nuh", "Noah", "নূহ", "Meccan", 28),
        SurahMeta(72, "الجن", "Al-Jinn", "The Jinn", "আল-জিন", "Meccan", 28),
        SurahMeta(73, "المزمل", "Al-Muzzammil", "The Enshrouded One", "আল-মুযযাম্মিল", "Meccan", 20),
        SurahMeta(74, "المدثر", "Al-Muddaththir", "The Cloaked One", "আল-মুদ্দাসসির", "Meccan", 56),
        SurahMeta(75, "القيامة", "Al-Qiyamah", "The Resurrection", "আল-কিয়ামাহ", "Meccan", 40),
        SurahMeta(76, "الإنسان", "Al-Insan", "Man", "আল-ইনসান", "Medinan", 31),
        SurahMeta(77, "المرسلات", "Al-Mursalat", "The Emissaries", "আল-মুরসালাত", "Meccan", 50),
        SurahMeta(78, "النبأ", "An-Naba", "The Tidings", "আন-নাবা", "Meccan", 40),
        SurahMeta(79, "النازعات", "An-Nazi'at", "Those Who Drag Forth", "আন-নাযিয়াত", "Meccan", 46),
        SurahMeta(80, "عبس", "Abasa", "He Frowned", "আবাসা", "Meccan", 42),
        SurahMeta(81, "التكوير", "At-Takwir", "The Overthrowing", "আত-তাকভীর", "Meccan", 29),
        SurahMeta(82, "الانفطار", "Al-Infitar", "The Cleaving", "আল-ইনফিতার", "Meccan", 19),
        SurahMeta(83, "المطففين", "Al-Mutaffifin", "Defrauding", "আল-মুতাফফিফীন", "Meccan", 36),
        SurahMeta(84, "الانشقاق", "Al-Inshiqaq", "The Sundering", "আল-ইনশিক্বাক্ব", "Meccan", 25),
        SurahMeta(85, "البروج", "Al-Buruj", "The Mansions of the Stars", "আল-বুরূজ", "Meccan", 22),
        SurahMeta(86, "الطارق", "At-Tariq", "The Morning Star", "আত-তারিক্ব", "Meccan", 17),
        SurahMeta(87, "الأعلى", "Al-A'la", "The Most High", "আল-আলা", "Meccan", 19),
        SurahMeta(88, "الغاشية", "Al-Ghashiyah", "The Overwhelming", "আল-গাশিয়াহ", "Meccan", 26),
        SurahMeta(89, "الفجر", "Al-Fajr", "The Dawn", "আল-ফজর", "Meccan", 30),
        SurahMeta(90, "البلد", "Al-Balad", "The City", "আল-বালাদ", "Meccan", 20),
        SurahMeta(91, "الشمس", "Ash-Shams", "The Sun", "আশ-শামস", "Meccan", 15),
        SurahMeta(92, "الليل", "Al-Layl", "The Night", "আল-লাইল", "Meccan", 21),
        SurahMeta(93, "الضحى", "Ad-Duha", "The Morning Hours", "আদ-দুহা", "Meccan", 11),
        SurahMeta(94, "الشرح", "Ash-Sharh", "The Consolation", "আশ-শারহ", "Meccan", 8),
        SurahMeta(95, "التين", "At-Tin", "The Fig", "আত-তীন", "Meccan", 8),
        SurahMeta(96, "العلق", "Al-Alaq", "The Clot", "আল-আলাক্ব", "Meccan", 19),
        SurahMeta(97, "القدر", "Al-Qadr", "The Power", "আল-ক্বদর", "Meccan", 5),
        SurahMeta(98, "البينة", "Al-Bayyinah", "The Clear Proof", "আল-বাইয়্যিনাহ", "Medinan", 8),
        SurahMeta(99, "الزلزلة", "Az-Zalzalah", "The Earthquake", "আয-যালযালাহ", "Medinan", 8),
        SurahMeta(100, "العاديات", "Al-Adiyat", "The Courser", "আল-আদিয়াত", "Meccan", 11),
        SurahMeta(101, "القارعة", "Al-Qari'ah", "The Calamity", "আল-ক্বারিআহ", "Meccan", 11),
        SurahMeta(102, "التكاثر", "At-Takathur", "The Rivalry in World Increase", "আত-তাকাসুর", "Meccan", 8),
        SurahMeta(103, "العصر", "Al-Asr", "The Declining Day", "আল-আসর", "Meccan", 3),
        SurahMeta(104, "الهمزة", "Al-Humazah", "The Traducer", "আল-হুমাযাহ", "Meccan", 9),
        SurahMeta(105, "الفيل", "Al-Fil", "The Elephant", "আল-ফীল", "Meccan", 5),
        SurahMeta(106, "قريش", "Quraysh", "Quraysh", "কুরাইশ", "Meccan", 4),
        SurahMeta(107, "الماعون", "Al-Ma'un", "The Small Kindnesses", "আল-মাউন", "Meccan", 7),
        SurahMeta(108, "الكوثر", "Al-Kauthar", "The Abundance", "আল-কাওসার", "Meccan", 3),
        SurahMeta(109, "الكافرون", "Al-Kafirun", "The Disbelievers", "আল-কাফিরুন", "Meccan", 6),
        SurahMeta(110, "النصر", "An-Nasr", "The Divine Support", "আন-নসর", "Medinan", 3),
        SurahMeta(111, "المসদ", "Al-Masad", "The Palm Fiber", "আল-মাসাদ", "Meccan", 5),
        SurahMeta(112, "الإخلاص", "Al-Ikhlas", "The Sincerity", "আল-ইখলাস", "Meccan", 4),
        SurahMeta(113, "الفلق", "Al-Falaq", "The Daybreak", "আল-ফালাক্ব", "Meccan", 5),
        SurahMeta(114, "الناس", "An-Nas", "Mankind", "আন-নাস", "Meccan", 6)
    )

    val preloadedDetailedSurahs = listOf(
        Surah(
            number = 1,
            name = "الفاتحة",
            englishName = "Al-Fatihah",
            englishNameTranslation = "The Opening",
            banglaName = "আল-ফাতিহা",
            revelationType = "Meccan",
            numberOfAyahs = 7,
            ayahs = listOf(
                Ayah(
                    numberInSurah = 1,
                    arabic = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                    english = "In the name of Allah, the Entirely Merciful, the Especially Merciful.",
                    bangla = "পরম করুণাময় অসীম দয়ালু আল্লাহর নামে শুরু করছি।",
                    wordByWord = listOf(
                        WordTranslation("بِسْمِ", "In name", "নামে"),
                        WordTranslation("اللَّهِ", "of Allah", "আল্লাহর"),
                        WordTranslation("الرَّحْمَٰنِ", "the Most Gracious", "পরম করুণাময়"),
                        WordTranslation("الرَّحِيمِ", "the Most Merciful", "অসীম দয়ালু")
                    ),
                    tafsir = "Al-Fatihah is the first chapter of the Quran. It is recited in every unit of prayer. It encapsulates the core monotheistic creed of Islam."
                ),
                Ayah(
                    numberInSurah = 2,
                    arabic = "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
                    english = "[All] praise is [due] to Allah, Lord of the worlds -",
                    bangla = "সব প্রশংসা আল্লাহর জন্য, যিনি সকল সৃষ্টির প্রতিপালক।",
                    wordByWord = listOf(
                        WordTranslation("الْحَمْدُ", "All praise", "সব প্রশংসা"),
                        WordTranslation("لِلَّهِ", "be to Allah", "আল্লাহর জন্য"),
                        WordTranslation("رَبِّ", "Lord", "প্রতিপালক"),
                        WordTranslation("الْعَالَمِينَ", "of the worlds", "সৃষ্টিজগতের")
                    ),
                    tafsir = "Praising Allah is the primary dynamic of a believer's connection to the Creator. 'Rabb' implies Sustainer, Provider, and Master."
                ),
                Ayah(
                    numberInSurah = 3,
                    arabic = "الرَّحْمَٰنِ الرَّحِيمِ",
                    english = "The Entirely Merciful, the Especially Merciful,",
                    bangla = "যিনি পরম করুণাময় ও অসীম দয়ালু।",
                    wordByWord = listOf(
                        WordTranslation("الرَّحْمَٰنِ", "the Most Gracious", "পরম করুণাময়"),
                        WordTranslation("الرَّحِيمِ", "the Most Merciful", "অসীম দয়ালু")
                    ),
                    tafsir = "Repetition of Mercy highlights that Allah's relationship with creation is fundamentally built on immense grace and love."
                ),
                Ayah(
                    numberInSurah = 4,
                    arabic = "مَالِكِ يَوْمِ الدِّينِ",
                    english = "Sovereign of the Day of Recompense.",
                    bangla = "যিনি বিচার দিবসের মালিক।",
                    wordByWord = listOf(
                        WordTranslation("مَالِكِ", "Sovereign/Master", "মালিক"),
                        WordTranslation("يَوْمِ", "of the Day", "দিনের"),
                        WordTranslation("الدِّينِ", "of Judgment", "বিচার")
                    ),
                    tafsir = "Establishes accountability. Justice will be served perfectly on the Day of Judgment, overseen solely by the Master of that day."
                ),
                Ayah(
                    numberInSurah = 5,
                    arabic = "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
                    english = "It is You we worship and You we ask for help.",
                    bangla = "আমরা একমাত্র আপনারই ইবাদত করি এবং একমাত্র আপনারই সাহায্য চাই।",
                    wordByWord = listOf(
                        WordTranslation("إِيَّاكَ", "You alone", "একমাত্র আপনারই"),
                        WordTranslation("نَعْبُدُ", "we worship", "আমরা ইবাদত করি"),
                        WordTranslation("وَإِيَّاكَ", "and You alone", "এবং একমাত্র আপনারই"),
                        WordTranslation("نَسْتَعِينُ", "we ask for help", "আমরা সাহায্য চাই")
                    ),
                    tafsir = "The cornerstone of Islamic Monotheism (Tawhid). Worship and seeking ultimate assistance are exclusive rights of Allah."
                ),
                Ayah(
                    numberInSurah = 6,
                    arabic = "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
                    english = "Guide us to the straight path -",
                    bangla = "আমাদের সরল পথ প্রদর্শন করুন।",
                    wordByWord = listOf(
                        WordTranslation("اهْدِنَا", "Guide us", "আমাদের পথ দেখান"),
                        WordTranslation("الصِّرَاطَ", "the path", "পথ"),
                        WordTranslation("الْمُسْتَقِيمَ", "straight", "সরল/সঠিক")
                    ),
                    tafsir = "Guidance (Hidayah) is the most critical asset for humans. The straight path is the balanced way of life leading to spiritual peace."
                ),
                Ayah(
                    numberInSurah = 7,
                    arabic = "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",
                    english = "The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.",
                    bangla = "তাদের পথ, যাদের আপনি নেয়ামত দান করেছেন; তাদের পথ নয় যারা আপনার ক্রোধের শিকার এবং পথভ্রষ্ট হয়েছে।",
                    wordByWord = listOf(
                        WordTranslation("صِرَاطَ", "path", "পথ"),
                        WordTranslation("الَّذِينَ", "of those", "তাদের"),
                        WordTranslation("أَنْعَمْتَ", "You favored", "আপনি অনুগ্রহ করেছেন"),
                        WordTranslation("عَلَيْهِمْ", "upon them", "তাদের ওপর"),
                        WordTranslation("غَيْرِ", "not", "নয়"),
                        WordTranslation("الْمَغْضُوبِ", "of those who earned anger", "ক্রোধের পাত্রদের"),
                        WordTranslation("وَلَا", "and not", "এবং নয়"),
                        WordTranslation("الضَّالِّينَ", "of those who go astray", "পথভ্রষ্টদের")
                    ),
                    tafsir = "We seek to follow the prophets, truth-lovers, and righteous people, avoiding arrogance (leading to wrath) and ignorance (leading to misguidance)."
                )
            )
        ),
        Surah(
            number = 108,
            name = "الكوثر",
            englishName = "Al-Kauthar",
            englishNameTranslation = "Abundance",
            banglaName = "আল-কাওসার",
            revelationType = "Meccan",
            numberOfAyahs = 3,
            ayahs = listOf(
                Ayah(
                    numberInSurah = 1,
                    arabic = "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ",
                    english = "Indeed, We have granted you, [O Muhammad], al-Kauthar.",
                    bangla = "নিশ্চয়ই আমি আপনাকে কাওসার (প্রচুর কল্যাণ) দান করেছি।",
                    wordByWord = listOf(
                        WordTranslation("إِنَّا", "Indeed We", "নিশ্চয়ই আমরা"),
                        WordTranslation("أَعْطَيْنَاكَ", "granted you", "তোমাকে দিয়েছি"),
                        WordTranslation("الْكَوْثَرَ", "the abundance", "কাওসার/অফুরন্ত কল্যাণ")
                    )
                ),
                Ayah(
                    numberInSurah = 2,
                    arabic = "فَصَلِّ لِرَبِّكَ وَانْحَرْ",
                    english = "So pray to your Lord and sacrifice [to Him alone].",
                    bangla = "অতএব আপনার প্রতিপালকের উদ্দেশ্যে সালাত আদায় করুন এবং কোরবানি করুন।",
                    wordByWord = listOf(
                        WordTranslation("فَصَلِّ", "So pray", "অতএব সালাত পড়ুন"),
                        WordTranslation("لِرَبِّكَ", "to your Lord", "তোমার রবের জন্য"),
                        WordTranslation("وَانْحَرْ", "and sacrifice", "এবং কোরবানি করুন")
                    )
                ),
                Ayah(
                    numberInSurah = 3,
                    arabic = "إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ",
                    english = "Indeed, your enemy is the one cut off.",
                    bangla = "নিশ্চয় আপনার কুৎসা রটনাকারীই তো নির্বংশ (লেজকাটা)।",
                    wordByWord = listOf(
                        WordTranslation("إِنَّ", "Indeed", "নিশ্চয়ই"),
                        WordTranslation("شَانِئَكَ", "your enemy", "তোমার শত্রু"),
                        WordTranslation("هُوَ", "he", "সে"),
                        WordTranslation("الْأَبْتَرُ", "the cut off", "নির্বংশ/লেজকাটা")
                    )
                )
            )
        ),
        Surah(
            number = 112,
            name = "الإخلاص",
            englishName = "Al-Ikhlas",
            englishNameTranslation = "Sincerity",
            banglaName = "আল-ইখলাস",
            revelationType = "Meccan",
            numberOfAyahs = 4,
            ayahs = listOf(
                Ayah(
                    numberInSurah = 1,
                    arabic = "قُلْ هُوَ اللَّهُ أَحَدٌ",
                    english = "Say, \"He is Allah, [who is] One,",
                    bangla = "বলুন, তিনিই আল্লাহ, একক-অদ্বিতীয়।",
                    wordByWord = listOf(
                        WordTranslation("قُلْ", "Say", "বলুন"),
                        WordTranslation("هُوَ", "He", "তিনি"),
                        WordTranslation("اللَّهُ", "[is] Allah", "আল্লাহ"),
                        WordTranslation("أَحَدٌ", "[who is] One", "একক")
                    )
                ),
                Ayah(
                    numberInSurah = 2,
                    arabic = "اللَّهُ الصَّمَدُ",
                    english = "Allah, the Eternal Refuge.",
                    bangla = "আল্লাহ কারো মুখাপেক্ষী নন, সবাই তাঁর মুখাপেক্ষী।",
                    wordByWord = listOf(
                        WordTranslation("اللَّهُ", "Allah", "আল্লাহ"),
                        WordTranslation("الصَّمَدُ", "the Eternal", "অমুখাপেক্ষী/অবিনশ্বর")
                    )
                ),
                Ayah(
                    numberInSurah = 3,
                    arabic = "لَمْ يَلِدْ وَلَمْ يُولَدْ",
                    english = "He neither begets nor is born,",
                    bangla = "তিনি কাউকে জন্ম দেননি এবং জন্ম নেনওনি।",
                    wordByWord = listOf(
                        WordTranslation("لَمْ", "Not", "না"),
                        WordTranslation("يَلِدْ", "He begets", "তিনি জন্ম দিয়েছেন"),
                        WordTranslation("وَلَمْ", "and not", "এবং না"),
                        WordTranslation("يُولَدْ", "He is born", "তিনি জন্ম নিয়েছেন")
                    )
                ),
                Ayah(
                    numberInSurah = 4,
                    arabic = "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ",
                    english = "And there is none co-equal or comparable to Him.\"",
                    bangla = "এবং তাঁর সমকক্ষ কেউই নেই।",
                    wordByWord = listOf(
                        WordTranslation("وَلَمْ", "And not", "এবং না"),
                        WordTranslation("يَكُن", "there is", "হয়েছে"),
                        WordTranslation("لَّهُ", "for Him", "তাঁর জন্য"),
                        WordTranslation("كُفُوًا", "equivalent", "সমকক্ষ"),
                        WordTranslation("أَحَدٌ", "anyone", "কেউ")
                    )
                )
            )
        ),
        Surah(
            number = 113,
            name = "الفلق",
            englishName = "Al-Falaq",
            englishNameTranslation = "The Daybreak",
            banglaName = "আল-ফালাক",
            revelationType = "Meccan",
            numberOfAyahs = 5,
            ayahs = listOf(
                Ayah(
                    numberInSurah = 1,
                    arabic = "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ",
                    english = "Say, \"I seek refuge in the Lord of daybreak",
                    bangla = "বলুন, আমি আশ্রয় প্রার্থনা করছি ঊষার প্রতিপালকের,",
                    wordByWord = listOf(
                        WordTranslation("قُلْ", "Say", "বলুন"),
                        WordTranslation("أَعُوذُ", "I seek refuge", "আমি আশ্রয় চাই"),
                        WordTranslation("بِرَبِّ", "in Lord", "রবের কাছে"),
                        WordTranslation("الْفَلَقِ", "of the daybreak", "ঊষার")
                    )
                ),
                Ayah(
                    numberInSurah = 2,
                    arabic = "مِن شَرِّ مَا خَلَقَ",
                    english = "From the evil of whatever He created",
                    bangla = "তিনি যা সৃষ্টি করেছেন, তার অনিষ্ট থেকে,",
                    wordByWord = listOf(
                        WordTranslation("مِن", "From", "থেকে"),
                        WordTranslation("شَرِّ", "evil", "অনিষ্ট/মন্দ"),
                        WordTranslation("مَا", "of what", "যা"),
                        WordTranslation("خَلَقَ", "He created", "তিনি সৃষ্টি করেছেন")
                    )
                ),
                Ayah(
                    numberInSurah = 3,
                    arabic = "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ",
                    english = "And from the evil of darkness when it settles",
                    bangla = "এবং অন্ধকার রাত্রির অনিষ্ট থেকে, যখন তা ঘনীভূত হয়,",
                    wordByWord = listOf(
                        WordTranslation("وَمِن", "And from", "এবং থেকে"),
                        WordTranslation("شَرِّ", "evil", "অনিষ্ট"),
                        WordTranslation("غَاسِقٍ", "of darkness", "অন্ধকারের"),
                        WordTranslation("إِذَا", "when", "যখন"),
                        WordTranslation("وَقَبَ", "it settles", "তা প্রবেশ করে")
                    )
                ),
                Ayah(
                    numberInSurah = 4,
                    arabic = "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ",
                    english = "And from the evil of the blowers in knots",
                    bangla = "এবং গ্রন্থিতে ফুঁৎকারদানকারী (জাদুকর) নারীদের অনিষ্ট থেকে,",
                    wordByWord = listOf(
                        WordTranslation("وَمِن", "And from", "এবং থেকে"),
                        WordTranslation("شَرِّ", "evil", "অনিষ্ট"),
                        WordTranslation("النَّفَّاثَاتِ", "of the blowers", "ফুঁৎকারদানকারিনীদের"),
                        WordTranslation("فِي", "in", "মধ্যে"),
                        WordTranslation("الْعُقَدِ", "the knots", "গ্রন্থি")
                    )
                ),
                Ayah(
                    numberInSurah = 5,
                    arabic = "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ",
                    english = "And from the evil of an envier when he envies.\"",
                    bangla = "এবং হিংসুকের অনিষ্ট থেকে, যখন সে হিংসা করে।",
                    wordByWord = listOf(
                        WordTranslation("وَمِن", "And from", "এবং থেকে"),
                        WordTranslation("شَرِّ", "evil", "অনিষ্ট"),
                        WordTranslation("حَاسِدٍ", "of an envier", "হিংসুকের"),
                        WordTranslation("إِذَا", "when", "যখন"),
                        WordTranslation("حَسَدَ", "he envies", "সে হিংসা করে")
                    )
                )
            )
        ),
        Surah(
            number = 114,
            name = "الناس",
            englishName = "An-Nas",
            englishNameTranslation = "Mankind",
            banglaName = "আন-নাস",
            revelationType = "Meccan",
            numberOfAyahs = 5,
            ayahs = listOf(
                Ayah(
                    numberInSurah = 1,
                    arabic = "قُلْ أَعُوذُ بِرَبِّ النَّاسِ",
                    english = "Say, \"I seek refuge in the Lord of mankind,",
                    bangla = "বলুন, আমি আশ্রয় প্রার্থনা করছি মানুষের প্রতিপালকের,",
                    wordByWord = listOf(
                        WordTranslation("قُلْ", "Say", "বলুন"),
                        WordTranslation("أَعُوذُ", "I seek refuge", "আমি আশ্রয় চাই"),
                        WordTranslation("بِرَبِّ", "in Lord", "রবের কাছে"),
                        WordTranslation("النَّاسِ", "of mankind", "মানুষের")
                    )
                ),
                Ayah(
                    numberInSurah = 2,
                    arabic = "مَلِكِ النَّاسِ",
                    english = "The Sovereign of mankind,",
                    bangla = "মানুষের অধিপতির,",
                    wordByWord = listOf(
                        WordTranslation("مَلِكِ", "The King", "রাজা/অধিপতি"),
                        WordTranslation("النَّاسِ", "of mankind", "মানুষের")
                    )
                ),
                Ayah(
                    numberInSurah = 3,
                    arabic = "إِلَٰهِ النَّاسِ",
                    english = "The God of mankind,",
                    bangla = "মানুষের ইলাহ বা উপাস্যের,",
                    wordByWord = listOf(
                        WordTranslation("إِلَٰهِ", "The God", "উপাস্য"),
                        WordTranslation("النَّاسِ", "of mankind", "মানুষের")
                    )
                ),
                Ayah(
                    numberInSurah = 4,
                    arabic = "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ",
                    english = "From the evil of the retreating whisperer -",
                    bangla = "আত্মগোপনকারী কুমন্ত্রণাদাতার অনিষ্ট হতে,",
                    wordByWord = listOf(
                        WordTranslation("مِن", "From", "হতে"),
                        WordTranslation("شَرِّ", "evil", "অনিষ্ট"),
                        WordTranslation("الْوَسْوَاسِ", "of whisperer", "কুমন্ত্রণাদাতার"),
                        WordTranslation("الْخَنَّاسِ", "the retreating", "আত্মগোপনকারী")
                    )
                ),
                Ayah(
                    numberInSurah = 5,
                    arabic = "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ",
                    english = "Who whispers [evil] into the breasts of mankind -",
                    bangla = "যে মানুষের অন্তরে কুমন্ত্রণা দেয়,",
                    wordByWord = listOf(
                        WordTranslation("الَّذِي", "who", "যে"),
                        WordTranslation("يُوَسْوِسُ", "whispers", "কুমন্ত্রণা দেয়"),
                        WordTranslation("فِي", "in", "মধ্যে"),
                        WordTranslation("صُدُورِ", "breasts", "বক্ষ/অন্তর"),
                        WordTranslation("النَّاسِ", "of mankind", "মানুষের")
                    )
                )
            )
        ),
        Surah(
            number = 36,
            name = "يس",
            englishName = "Yaseen",
            englishNameTranslation = "Yaseen",
            banglaName = "ইয়াসীন",
            revelationType = "Meccan",
            numberOfAyahs = 83,
            ayahs = listOf(
                Ayah(
                    numberInSurah = 1,
                    arabic = "يس",
                    english = "Ya, Seen.",
                    bangla = "ইয়া-সীন।",
                    wordByWord = listOf(WordTranslation("يس", "Ya Seen", "ইয়া-সীন"))
                ),
                Ayah(
                    numberInSurah = 2,
                    arabic = "وَالْقُرْآنِ الْحَكِيمِ",
                    english = "By the wise Qur'an,",
                    bangla = "প্রজ্ঞাময় কুরআনের শপথ,",
                    wordByWord = listOf(
                        WordTranslation("وَالْقُرْآنِ", "By the Quran", "কুরআনের শপথ"),
                        WordTranslation("الْحَكِيمِ", "the wise", "প্রজ্ঞাময়")
                    )
                ),
                Ayah(
                    numberInSurah = 3,
                    arabic = "إِنَّكَ لَمِنَ الْمُرْسَلِينَ",
                    english = "Indeed you, [O Muhammad], are of the messengers,",
                    bangla = "নিশ্চয়ই আপনি রাসুলদের অন্তর্ভুক্ত।",
                    wordByWord = listOf(
                        WordTranslation("إِنَّكَ", "Indeed you", "নিশ্চয়ই আপনি"),
                        WordTranslation("لَمِنَ", "are of", "মধ্যে"),
                        WordTranslation("الْمُرْسَلِينَ", "the messengers", "রাসূলগণের")
                    )
                )
            )
        )
    )

    val surahs: List<Surah> = surahsMetadata.map { meta ->
        val preloaded = preloadedDetailedSurahs.find { it.number == meta.number }
        if (preloaded != null) {
            preloaded
        } else {
            Surah(
                number = meta.number,
                name = meta.name,
                englishName = meta.englishName,
                englishNameTranslation = meta.englishNameTranslation,
                banglaName = meta.banglaName,
                revelationType = meta.revelationType,
                numberOfAyahs = meta.numberOfAyahs,
                ayahs = generateDynamicAyahsForSurah(meta)
            )
        }
    }

    val hadiths = listOf(
        Hadith(
            id = 1,
            book = "Sahih Bukhari",
            chapter = "Revelation",
            narrator = "Umar bin Al-Khattab",
            arabic = "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى",
            english = "The reward of deeds depends upon the intentions and every person will get the reward according to what he has intended.",
            bangla = "নিশ্চয়ই সমস্ত কাজের ফলাফল নিয়তের ওপর নির্ভরশীল। প্রত্যেক ব্যক্তি তাই পাবে যার সে নিয়ত করবে।",
            reference = "Sahih al-Bukhari 1"
        ),
        Hadith(
            id = 2,
            book = "Sahih Bukhari",
            chapter = "Belief",
            narrator = "Abu Hurairah",
            arabic = "الْإِيمَانُ بِضْعٌ وَسَبْعُونَ أَوْ بِضْعٌ وَسِتُّونَ شُعْبَةً، فَأَفْضَلُهَا قَوْلُ لَا إِلَهَ إِلَّا اللَّهُ، وَأَدْنَاهَا إِمَاطَةُ الْأَذَى عَنِ الطَّرِيقِ، وَالْحَيَاءُ شُعْبَةٌ مِنَ الْإِيمَانِ",
            english = "Faith has over seventy branches, the most excellent of which is the declaration that there is no god but Allah, and the humblest of which is the removal of what is injurious from the path: and modesty is a branch of faith.",
            bangla = "ঈমানের সত্তরটিরও বেশি শাখা রয়েছে। তার মধ্যে সর্বোত্তম শাখা হচ্ছে ‘লা ইলাহা ইল্লাল্লাহ’ বলা এবং সর্বনিম্ন শাখা হচ্ছে পথ থেকে কষ্টদায়ক বস্তু সরিয়ে ফেলা। আর লজ্জা হচ্ছে ঈমানের অন্যতম একটি গুরুত্বপূর্ণ শাখা।",
            reference = "Sahih al-Bukhari 9"
        ),
        Hadith(
            id = 3,
            book = "Sahih Muslim",
            chapter = "Purification",
            narrator = "Abu Malik al-Ash'ari",
            arabic = "الطَّهُورُ شَطْرُ الإِيمَانِ",
            english = "Purity is half of faith.",
            bangla = "পবিত্রতা ঈমানের অর্ধেক।",
            reference = "Sahih Muslim 223"
        ),
        Hadith(
            id = 4,
            book = "Riyad-us-Saliheen",
            chapter = "Good Character",
            narrator = "Abu Hurairah",
            arabic = "إِنَّمَا بُعِثْتُ لِأُتَمِّمَ صَالِحَ الْأَخْلَاقِ",
            english = "I have only been sent to perfect good character.",
            bangla = "আমি উত্তম চরিত্রের পূর্ণতা সাধনের জন্যই প্রেরিত হয়েছি।",
            reference = "Riyad-us-Saliheen 612"
        )
    )

    val duas = listOf(
        Dua(
            id = 1,
            category = "Morning",
            title = "Dua for Waking Up",
            arabic = "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ",
            transliteration = "Alhamdu lillahil-ladhi ahyana ba'da ma amatana wa ilayhin-nushur",
            transliterationBn = "আলহামদু লিল্লাহিল্লাজি আহইয়ানা বা’দা মা আমাতানা ওয়া ইলাইহিন নুশুর",
            english = "All praise is for Allah who gave us life after having taken it from us and unto Him is the resurrection.",
            bangla = "সমস্ত প্রশংসা আল্লাহর জন্য, যিনি আমাদের মৃত্যুর পর পুনরায় জীবিত করলেন এবং তাঁর দিকেই ফিরে যেতে হবে।"
        ),
        Dua(
            id = 2,
            category = "Evening",
            title = "Protection from Harm",
            arabic = "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
            transliteration = "Bismillahil-ladhi la yadurru ma'as-mihi shay'un fil-ardi wa la fis-sama'i wa Huwas-Sami'ul-'Alim",
            transliterationBn = "বিসমিল্লাহিল্লাজি লা ইয়াদুররু মা’আসমিহি শাইউন ফিল আরদি ওয়া লা ফিস সামায়ি ওয়া হুয়াস সামিউল আলিম",
            english = "In the Name of Allah, Who with His Name nothing can cause harm in the earth nor in the heavens, and He is the All-Hearing, the All-Knowing.",
            bangla = "আল্লাহর নামে, যাঁর নামের বরকতে আসমান ও জমিনের কোনো কিছুই কোনো ক্ষতি করতে পারে না, আর তিনি সর্বশ্রোতা, সর্বজ্ঞাতা।"
        ),
        Dua(
            id = 3,
            category = "Daily",
            title = "Seeking Knowledge",
            arabic = "رَّبِّ زِدْنِي عِلْمًا",
            transliteration = "Rabbi zidni 'ilma",
            transliterationBn = "রাব্বি জিদনি ইলমা",
            english = "My Lord, increase me in knowledge.",
            bangla = "হে আমার প্রতিপালক! আমার জ্ঞান বৃদ্ধি করে দিন।"
        )
    )

    val books = listOf(
        IslamicBook(
            id = 1,
            title = "Riyad-us-Saliheen",
            titleBn = "রিয়াদুস সালেহীন",
            author = "Imam An-Nawawi",
            authorBn = "ইমাম আন-নাবাবী",
            description = "A comprehensive collection of verses from Quran and authentic Hadiths covering all aspects of Islamic belief and moral conduct.",
            descriptionBn = "কুরআনের আয়াত এবং সহীহ হাদিসের একটি বিস্তৃত সংগ্রহ যা ইসলামী বিশ্বাস এবং নৈতিক আচরণের সমস্ত দিক কভার করে।",
            pages = 450,
            chapters = listOf("Introduction", "Sincerity & Intention", "Patience & Perseverance", "Truthfulness", "Watchfulness", "Fear & Hope"),
            chaptersBn = listOf("ভূমিকা", "নিয়ত ও আন্তরিকতা", "ধৈর্য ও দৃঢ়তা", "সত্যবাদিতা", "সতর্কতা", "ভয় ও আশা")
        ),
        IslamicBook(
            id = 2,
            title = "Hisnul Muslim",
            titleBn = "হিসনুল মুসলিম",
            author = "Sa'id bin Ali al-Qahtani",
            authorBn = "সাঈদ বিন আলী আল-কাহতানি",
            description = "Fortress of the Muslim, Invocations from the Quran and Sunnah. One of the most popular daily prayer/dua compilation.",
            descriptionBn = "মুসলিমদের দুর্গ, কুরআন ও সুন্নাহ থেকে দোয়া ও জিকিরের সংকলন। দৈনিক দোয়া প্রার্থনার অন্যতম জনপ্রিয় বই।",
            pages = 180,
            chapters = listOf("Morning Supplications", "Evening Supplications", "Dua before Sleep", "Dua upon waking up", "Supplications for Rain"),
            chaptersBn = listOf("সকালের দোয়া ও জিকির", "সন্ধ্যার দোয়া ও জিকির", "ঘুমানোর পূর্বের দোয়া", "ঘুম থেকে ওঠার দোয়া", "বৃষ্টির জন্য দোয়া")
        )
    )

    val quizQuestions = listOf(
        QuizQuestion(
            id = 1,
            question = "How many Surahs are there in the Holy Quran?",
            options = listOf("110", "114", "124", "144"),
            correctAnswerIndex = 1,
            explanation = "The Holy Quran consists of 114 Surahs (chapters), starting with Al-Fatihah and ending with An-Nas."
        ),
        QuizQuestion(
            id = 2,
            question = "In which month was the Quran first revealed?",
            options = listOf("Muharram", "Rajab", "Ramadan", "Dhul-Hijjah"),
            correctAnswerIndex = 2,
            explanation = "The Holy Quran was first revealed to Prophet Muhammad (PBUH) in the cave of Hira during the holy month of Ramadan on the Night of Power (Laylat al-Qadr)."
        ),
        QuizQuestion(
            id = 3,
            question = "What is the primary meaning of the word 'Islam'?",
            options = listOf("Prayer", "Charity", "Submission and Peace", "Struggle"),
            correctAnswerIndex = 2,
            explanation = "Islam is derived from the Arabic root 'S-L-M' which means peace, safety, and submission to the will of Allah."
        )
    )
}
