package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    secondary = GoldAccent,
    tertiary = IslamicGreenLight,
    background = LuxuryDarkBg,
    surface = LuxuryDarkSurface,
    onPrimary = LuxuryDarkBg,
    onSecondary = Color.White,
    onTertiary = IslamicGreenSecondary,
    onBackground = CreamWhite,
    onSurface = CreamWhite,
    surfaceVariant = Color(0xFF143827),
    onSurfaceVariant = GoldAccent
)

private val LightColorScheme = lightColorScheme(
    primary = IslamicGreenPrimary,
    secondary = IslamicGreenSecondary,
    tertiary = GoldPrimary,
    background = CreamWhite,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = IslamicGreenSecondary,
    onBackground = IslamicGreenSecondary,
    onSurface = IslamicGreenSecondary,
    surfaceVariant = IslamicGreenLight,
    onSurfaceVariant = IslamicGreenPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
