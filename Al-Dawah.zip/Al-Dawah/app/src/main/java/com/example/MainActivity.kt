package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ImaanHubViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val viewModel: ImaanHubViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
            MyApplicationTheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ImaanHubApp(viewModel = viewModel)
                }
            }
        }
    }
}

// ----------------------------------------------------
// LOCALIZATION TRANSLATION HELPERS
// ----------------------------------------------------
fun t(en: String, bn: String, lang: String): String {
    return if (lang == "Bangla") bn else en
}

fun translatePrayerName(name: String, lang: String): String {
    if (lang != "Bangla") return name
    return when (name) {
        "Fajr" -> "ফজর"
        "Dhuhr" -> "যোহর"
        "Asr" -> "আসর"
        "Maghrib" -> "মাগরিব"
        "Isha" -> "ইশা"
        else -> name
    }
}

fun translateNumber(num: String, lang: String): String {
    if (lang != "Bangla") return num
    val converted = num
        .replace("AM", "এএম", ignoreCase = true)
        .replace("PM", "পিএম", ignoreCase = true)
    return converted.map {
        when (it) {
            '0' -> '০'
            '1' -> '১'
            '2' -> '২'
            '3' -> '৩'
            '4' -> '৪'
            '5' -> '৫'
            '6' -> '৬'
            '7' -> '৭'
            '8' -> '৮'
            '9' -> '৯'
            else -> it
        }
    }.joinToString("")
}

fun translateRevelationType(type: String, lang: String): String {
    if (lang != "Bangla") return type
    return if (type == "Meccan") "মাক্কী" else "মাদানী"
}

fun translateVersesCount(count: Int, lang: String): String {
    if (lang != "Bangla") return "$count Verses"
    return "${translateNumber(count.toString(), lang)} টি আয়াত"
}

fun translateDuaCategory(category: String, lang: String): String {
    if (lang != "Bangla") return category
    return when (category) {
        "Morning" -> "সকাল"
        "Evening" -> "সন্ধ্যা"
        "Daily" -> "দৈনন্দিন"
        "Hisnul Muslim" -> "হিসনুল মুসলিম"
        else -> category
    }
}

fun translateDuaTitle(title: String, lang: String): String {
    if (lang != "Bangla") return title
    return when (title) {
        "Dua for Waking Up" -> "ঘুম থেকে ওঠার দোয়া"
        "Protection from Harm" -> "ক্ষতি থেকে রক্ষার দোয়া"
        "Seeking Knowledge" -> "জ্ঞান বৃদ্ধির দোয়া"
        else -> title
    }
}

// ----------------------------------------------------
// MAIN APP COMPOSABLE
// ----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImaanHubApp(viewModel: ImaanHubViewModel) {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf("home") }
    
    // Sub-screens under "home" or "settings" via simple state stack
    var activeSubScreen by remember { mutableStateOf<String?>(null) }
    
    val selectedSurah by viewModel.selectedSurah.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    var showSplash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2500) // Show splash for 2.5 seconds
        showSplash = false
    }

    if (showSplash) {
        SplashScreen()
    } else {
        Scaffold(
            bottomBar = {
                if (activeSubScreen == null) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp,
                        modifier = Modifier.navigationBarsPadding().testTag("bottom_nav")
                    ) {
                        val items = listOf(
                            Triple("home", Icons.Outlined.Home, t("Home", "হোম", currentLanguage)),
                            Triple("quran", Icons.Outlined.Book, t("Quran", "কুরআন", currentLanguage)),
                            Triple("hadith", Icons.Outlined.MenuBook, t("Hadith", "হাদিস", currentLanguage)),
                            Triple("prayer", Icons.Outlined.AccessTime, t("Prayer", "নামাজ", currentLanguage)),
                            Triple("settings", Icons.Outlined.Settings, t("Settings", "সেটিংস", currentLanguage))
                        )
                        items.forEach { (screen, icon, label) ->
                            val selected = currentScreen == screen
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    currentScreen = screen
                                    activeSubScreen = null
                                },
                                icon = {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                },
                                label = {
                                    Text(
                                        text = label,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 11.sp
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Background Image/Gradient Decoration
                Image(
                    painter = painterResource(id = R.drawable.img_islamic_bg_1784350054399),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxSize()
                        .alpha(if (isDarkTheme) 0.08f else 0.15f),
                    contentScale = ContentScale.Crop
                )

                // Screen Navigation Resolver
                AnimatedContent(
                    targetState = activeSubScreen ?: currentScreen,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(250)) togetherWith fadeOut(animationSpec = tween(200))
                    },
                    label = "ScreenTransition"
                ) { target ->
                    when (target) {
                        "home" -> HomeScreen(viewModel = viewModel, onNavigateToSub = { activeSubScreen = it })
                        "quran" -> QuranScreen(viewModel = viewModel, onReadSurah = { activeSubScreen = "quran_reader" })
                        "quran_reader" -> QuranReaderScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                        "hadith" -> HadithScreen(viewModel = viewModel)
                        "prayer" -> PrayerScreen(viewModel = viewModel, onNavigateToSub = { activeSubScreen = it })
                        "settings" -> SettingsScreen(viewModel = viewModel, onNavigateToSub = { activeSubScreen = it })
                        
                        // Sub Screens
                        "hafezi_quran" -> HafeziQuranScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                        "tasbih" -> TasbihScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                        "duas" -> DuasScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                        "quiz" -> QuizScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                        "zakat" -> ZakatScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                        "mosque" -> MosqueFinderScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                        "notes" -> NotesScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                        "hajj" -> HajjGuideScreen(onBack = { activeSubScreen = null })
                        "books" -> IslamicBooksScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// HOME SCREEN
// ----------------------------------------------------
@Composable
fun HomeScreen(viewModel: ImaanHubViewModel, onNavigateToSub: (String) -> Unit) {
    val countdown by viewModel.nextPrayerCountdown.collectAsStateWithLifecycle()
    val nextPrayerName by viewModel.nextPrayerName.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val selectedDistrict by viewModel.selectedDistrict.collectAsStateWithLifecycle()
    var showDistrictDialog by remember { mutableStateOf(false) }
    var showPrayerScheduleDialog by remember { mutableStateOf(false) }
    
    val locale = if (currentLanguage == "Bangla") Locale("bn", "BD") else Locale.getDefault()
    val df = SimpleDateFormat("EEEE, dd MMMM yyyy", locale)
    val formattedDate = df.format(Date())

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App header & Islamic greeting
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = t("Assalamu Alaikum", "আসসালামু আলাইকুম", currentLanguage),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                }
                
                // Elegant gold-styled crescent dome avatar
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Brightness3,
                        contentDescription = "Profile",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Search bar
        item {
            var searchStr by remember { mutableStateOf("") }
            OutlinedTextField(
                value = searchStr,
                onValueChange = { searchStr = it },
                placeholder = { Text(t("Search Quran, Hadith, Duas...", "কুরআন, হাদিস, দুয়া খুঁজুন...", currentLanguage)) },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search"),
                shape = RoundedCornerShape(24.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )
        }

        // Prayer Time & Countdown premium card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("prayer_times_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .drawBehind {
                            // Gold geometric subtle accent lines
                            drawCircle(
                                color = Color(0x1AD4AF37),
                                radius = 240.dp.toPx(),
                                center = Offset(size.width, 0f)
                            )
                        }
                        .padding(20.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${t("Next Prayer", "পরবর্তী নামাজ", currentLanguage)}: ${translatePrayerName(nextPrayerName, currentLanguage)}",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White.copy(alpha = 0.15f))
                                    .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .clickable { showDistrictDialog = true }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "Location",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = t(selectedDistrict.nameEn, selectedDistrict.nameBn, currentLanguage),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Change Location",
                                    tint = Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Text(
                            text = translateNumber(countdown, currentLanguage),
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.tertiary,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "${t("Time remaining for", "সময় বাকি আছে", currentLanguage)} ${translatePrayerName(nextPrayerName, currentLanguage)} ${t("prayer. Set Azan notifications below.", "নামাজের জন্য। নিচে আজান সেট করুন।", currentLanguage)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // Button to open Prayer Schedule Dialog
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showPrayerScheduleDialog = true },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = t("Full Prayer Schedule", "পাঁচ ওয়াক্ত নামাজের সময়সূচী", currentLanguage),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = t("Tap to view today's times", "আজকের নামাজের সময় দেখতে ট্যাপ করুন", currentLanguage),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "View",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Quick feature grid items
        item {
            Text(
                text = t("Explore Features", "ফিচারসমূহ অন্বেষণ করুন", currentLanguage),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val features = listOf(
                    Triple("hafezi_quran", Icons.Outlined.MenuBook, t("Hafezi Quran", "হাফেজী কুরআন", currentLanguage)),
                    Triple("tasbih", Icons.Default.Fingerprint, t("Digital Tasbih", "ডিজিটাল তাসবিহ", currentLanguage)),
                    Triple("duas", Icons.Default.Favorite, t("Hisnul Muslim Duas", "হিসনুল মুসলিম দুয়া", currentLanguage)),
                    Triple("quiz", Icons.Default.Quiz, t("Islamic Quiz", "ইসলামী কুইজ", currentLanguage)),
                    Triple("zakat", Icons.Default.Calculate, t("Zakat Calculator", "যাকাত ক্যালকুলেটর", currentLanguage)),
                    Triple("mosque", Icons.Default.Place, t("Mosque Finder", "মসজিদ সন্ধান", currentLanguage)),
                    Triple("hajj", Icons.Default.DirectionsWalk, t("Hajj & Umrah", "হজ ও ওমরাহ", currentLanguage)),
                    Triple("notes", Icons.Default.EditNote, t("Islamic Notes", "ইসলামী নোটস", currentLanguage)),
                    Triple("books", Icons.Default.LibraryBooks, t("Islamic Books", "ইসলামী বইসমূহ", currentLanguage))
                )
                
                // Construct beautiful 2-column feature grids
                for (i in features.indices step 2) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (j in 0..1) {
                            if (i + j < features.size) {
                                val item = features[i + j]
                                FeatureCard(
                                    imageVector = item.second,
                                    title = item.third,
                                    onClick = { onNavigateToSub(item.first) },
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // Daily verse & Daily Hadith beautiful expandable cards
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = t("Daily Quran Verse", "আজকের কুরআনের আয়াত", currentLanguage),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                    }
                    Text(
                        text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nاهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
                        style = MaterialTheme.typography.titleLarge,
                        textAlign = TextAlign.Right,
                        fontStyle = FontStyle.Normal,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = t("Guide us to the straight path - (Surah Al-Fatihah, Verse 6)", "আমাদের সরল পথ দেখান - (সূরা আল-ফাতিহা, আয়াত ৬)", currentLanguage),
                        style = MaterialTheme.typography.bodyMedium,
                        fontStyle = FontStyle.Italic
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = t("Daily Hadith Insight", "আজকের হাদিসের বাণী", currentLanguage),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                    }
                    Text(
                        text = t("\"The reward of deeds depends upon the intentions...\"", "\"নিশ্চয়ই সকল কাজের ফলাফল নিয়তের উপর নির্ভরশীল...\"", currentLanguage),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = t("- Sahih al-Bukhari 1", "- সহীহ আল-বুখারী ১", currentLanguage),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }

    // Beautiful Location/District Choice Dialog
    if (showDistrictDialog) {
        Dialog(onDismissRequest = { showDistrictDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = t("Select Location / District", "স্থান / জেলা নির্বাচন করুন", currentLanguage),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    LazyColumn(
                        modifier = Modifier.heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(viewModel.districtList) { district ->
                            val isCurrent = district.id == selectedDistrict.id
                            val cardColor = if (isCurrent) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            }
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectDistrict(district)
                                        showDistrictDialog = false
                                    },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = cardColor),
                                border = if (isCurrent) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = district.nameEn,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = district.nameBn,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    }
                                    if (isCurrent) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    TextButton(
                        onClick = { showDistrictDialog = false },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(t("Close", "বন্ধ করুন", currentLanguage))
                    }
                }
            }
        }
    }

    // Beautiful Prayer Times Schedule Dialog
    if (showPrayerScheduleDialog) {
        Dialog(onDismissRequest = { showPrayerScheduleDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "${t("Prayer Schedule", "নামাজের সময়সূচী", currentLanguage)} - ${t(selectedDistrict.nameEn, selectedDistrict.nameBn, currentLanguage)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val prayers = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
                        prayers.forEach { prayer ->
                            val time = viewModel.getPrayerTimeForDistrict(prayer, selectedDistrict)
                            val prayerLabel = translatePrayerName(prayer, currentLanguage)
                            val formattedTime = translateNumber(time, currentLanguage)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = if (prayer == nextPrayerName) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (prayer == nextPrayerName) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "Next",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    Text(
                                        text = prayerLabel,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (prayer == nextPrayerName) FontWeight.Bold else FontWeight.SemiBold,
                                        color = if (prayer == nextPrayerName) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = formattedTime,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (prayer == nextPrayerName) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                )
                            }
                            if (prayer != "Isha") {
                                HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.05f))
                            }
                        }
                    }

                    TextButton(
                        onClick = { showPrayerScheduleDialog = false },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(t("Close", "বন্ধ করুন", currentLanguage))
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureCard(
    imageVector: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(90.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = imageVector,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ----------------------------------------------------
// QURAN SCREEN
// ----------------------------------------------------
@Composable
fun QuranScreen(viewModel: ImaanHubViewModel, onReadSurah: () -> Unit) {
    val quranSearchQuery by viewModel.quranSearchQuery.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    
    val filteredSurahs = remember(quranSearchQuery) {
        if (quranSearchQuery.isBlank()) {
            IslamicData.surahs
        } else {
            IslamicData.surahs.filter {
                it.englishName.contains(quranSearchQuery, ignoreCase = true) ||
                        it.banglaName.contains(quranSearchQuery)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = t("Holy Quran", "পবিত্র কুরআন", currentLanguage),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        OutlinedTextField(
            value = quranSearchQuery,
            onValueChange = { viewModel.setQuranSearchQuery(it) },
            placeholder = { Text(t("Search Surah name...", "সূরার নাম খুঁজুন...", currentLanguage)) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("quran_search"),
            shape = RoundedCornerShape(16.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredSurahs) { surah ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.selectSurah(surah)
                            onReadSurah()
                        },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Surah Number inside stylized gold polygon badge
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(
                                        MaterialTheme.colorScheme.primaryContainer,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = translateNumber(surah.number.toString(), currentLanguage),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = t(surah.englishName, surah.banglaName, currentLanguage),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${translateRevelationType(surah.revelationType, currentLanguage)} • ${translateVersesCount(surah.numberOfAyahs, currentLanguage)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = surah.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = t(surah.banglaName, surah.englishName, currentLanguage),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// SMART QURAN READER & RECITATION HIGHLIGHTER
// ----------------------------------------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun QuranReaderScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val surah by viewModel.selectedSurah.collectAsStateWithLifecycle()
    val activeAyahIndex by viewModel.currentAyahIndex.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val playbackSpeed by viewModel.playbackSpeed.collectAsStateWithLifecycle()
    val isAutoScroll by viewModel.isAutoScroll.collectAsStateWithLifecycle()
    val sleepTimerRemaining by viewModel.sleepTimerMinutes.collectAsStateWithLifecycle()
    val selectedQari by viewModel.selectedQari.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Trigger auto scroll to highlight verse if enabled
    LaunchedEffect(activeAyahIndex, isAutoScroll) {
        if (isAutoScroll && surah.ayahs.isNotEmpty()) {
            scope.launch {
                listState.animateScrollToItem(activeAyahIndex)
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Reader Header Topbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = t(surah.englishName, surah.banglaName, currentLanguage),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${t(surah.englishNameTranslation, surah.banglaName, currentLanguage)} • ${translateRevelationType(surah.revelationType, currentLanguage)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            IconButton(onClick = {
                viewModel.toggleBookmark(
                    type = "quran",
                    title = surah.englishName,
                    subtitle = "Bookmarked Surah",
                    refId = surah.number.toString()
                )
            }) {
                val bookmarked by viewModel.isBookmarked("quran", surah.number.toString()).collectAsStateWithLifecycle()
                Icon(
                    imageVector = if (bookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    contentDescription = "Bookmark",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Bismillah Banner for non-Fatihah
        if (surah.number != 1 && surah.ayahs.isNotEmpty()) {
            Text(
                text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Quran Verses List View
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            itemsIndexed(surah.ayahs) { index, ayah ->
                val isActive = index == activeAyahIndex
                
                // Active Glowing Border & Smooth highlight animation
                val elevation by animateDpAsState(if (isActive) 8.dp else 0.dp, label = "elevation")
                val containerColor = if (isActive) {
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                } else {
                    MaterialTheme.colorScheme.surface
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = { viewModel.selectAyah(index) },
                            onLongClick = {
                                viewModel.toggleBookmark(
                                    type = "ayah",
                                    title = t("Ayah ${ayah.numberInSurah} of ${surah.englishName}", "${surah.banglaName} সূরার ${translateNumber(ayah.numberInSurah.toString(), currentLanguage)} নং আয়াত", currentLanguage),
                                    subtitle = ayah.arabic,
                                    refId = "${surah.number}:${ayah.numberInSurah}",
                                    arabicText = ayah.arabic,
                                    translationText = ayah.english
                                )
                            }
                        ),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = containerColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = elevation),
                    border = if (isActive) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Header info of Ayah
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${translateNumber(surah.number.toString(), currentLanguage)}:${translateNumber(ayah.numberInSurah.toString(), currentLanguage)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(onClick = {
                                    // Simulated audio recite trigger
                                    viewModel.selectAyah(index)
                                }) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Recite",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }

                        // Detailed Arabic Text
                        Text(
                            text = ayah.arabic,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontSize = 24.sp,
                                lineHeight = 38.sp
                            ),
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth(),
                            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )

                        // Word by word expansion layout if present
                        if (ayah.wordByWord.isNotEmpty()) {
                            FlowRow(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.End
                            ) {
                                ayah.wordByWord.forEach { word ->
                                    Card(
                                        modifier = Modifier.padding(4.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(6.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(text = word.arabic, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                            Text(text = t(word.english, word.bangla, currentLanguage), style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // English Translation
                        Text(
                            text = "${t("English", "ইংরেজী", currentLanguage)}: ${ayah.english}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )

                        // Bangla Translation
                        Text(
                            text = "${t("Bangla", "বাংলা", currentLanguage)}: ${ayah.bangla}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                            fontWeight = FontWeight.Bold
                        )

                        if (ayah.tafsir.isNotBlank()) {
                            Text(
                                text = "Tafsir: ${ayah.tafsir}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }
        }

        // Beautiful Reciter Player Bar Bottom Widget
        Surface(
            modifier = Modifier.fillMaxWidth(),
            tonalElevation = 8.dp,
            shadowElevation = 16.dp,
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Qari selection row
                var showQariDialog by remember { mutableStateOf(false) }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showQariDialog = true }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Qari Voice",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = t("Selected Qari", "নির্বাচিত কারী", currentLanguage),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            )
                            Text(
                                text = if (currentLanguage == "Bangla") selectedQari.banglaName else selectedQari.name,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Change Qari",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))

                // Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.toggleAutoScroll() }) {
                        Icon(
                            imageVector = if (isAutoScroll) Icons.Default.SwapCalls else Icons.Default.VerticalAlignTop,
                            contentDescription = "Auto Scroll",
                            tint = if (isAutoScroll) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { viewModel.prevAyah() }) {
                            Icon(imageVector = Icons.Default.SkipPrevious, contentDescription = "Prev")
                        }

                        FloatingActionButton(
                            onClick = { viewModel.togglePlayPause() },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White,
                            shape = CircleShape
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play"
                            )
                        }

                        IconButton(onClick = { viewModel.nextAyah() }) {
                            Icon(imageVector = Icons.Default.SkipNext, contentDescription = "Next")
                        }
                    }

                    // Playback Speed Toggle
                    TextButton(onClick = {
                        val newSpeed = when (playbackSpeed) {
                            1.0f -> 1.25f
                            1.25f -> 1.5f
                            1.5f -> 0.75f
                            else -> 1.0f
                        }
                        viewModel.setPlaybackSpeed(newSpeed)
                    }) {
                        Text(text = "${translateNumber(playbackSpeed.toString(), currentLanguage)}x", fontWeight = FontWeight.Bold)
                    }
                }

                // Sleep Timer details
                if (sleepTimerRemaining > 0) {
                    Text(
                        text = t(
                            "Sleep Timer active: Recitation shuts off in $sleepTimerRemaining minutes",
                            "স্লিপ টাইমার সক্রিয়: ${translateNumber(sleepTimerRemaining.toString(), currentLanguage)} মিনিট পর তিলাওয়াত বন্ধ হবে",
                            currentLanguage
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Beautiful Qari Choice Dialog
                if (showQariDialog) {
                    Dialog(onDismissRequest = { showQariDialog = false }) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "Select Reciter / কারী নির্বাচন করুন",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Center
                                )

                                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                                LazyColumn(
                                    modifier = Modifier.heightIn(max = 300.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(viewModel.qariList) { qari ->
                                        val isCurrent = qari.id == selectedQari.id
                                        val cardColor = if (isCurrent) {
                                            MaterialTheme.colorScheme.primaryContainer
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                        }
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    viewModel.selectQari(qari)
                                                    showQariDialog = false
                                                },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = cardColor),
                                            border = if (isCurrent) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = qari.name,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Text(
                                                        text = qari.banglaName,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                                    )
                                                }
                                                if (isCurrent) {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = "Selected",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                TextButton(
                                    onClick = { showQariDialog = false },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text("Close / বন্ধ করুন")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Minimal FlowRow Composable for word-by-word
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    content: @Composable () -> Unit
) {
    androidx.compose.ui.layout.Layout(
        content = content,
        modifier = modifier
    ) { measurables, constraints ->
        val placeables = measurables.map { it.measure(constraints) }
        var rowWidth = 0
        var rowHeight = 0
        val rows = mutableListOf<List<androidx.compose.ui.layout.Placeable>>()
        var currentRow = mutableListOf<androidx.compose.ui.layout.Placeable>()

        placeables.forEach { placeable ->
            if (rowWidth + placeable.width > constraints.maxWidth) {
                rows.add(currentRow)
                currentRow = mutableListOf()
                rowWidth = 0
            }
            currentRow.add(placeable)
            rowWidth += placeable.width
        }
        if (currentRow.isNotEmpty()) {
            rows.add(currentRow)
        }

        val height = rows.sumOf { r -> r.maxOfOrNull { it.height } ?: 0 }
        layout(constraints.maxWidth, height) {
            var y = 0
            rows.forEach { row ->
                var x = if (horizontalArrangement == Arrangement.End) constraints.maxWidth - row.sumOf { it.width } else 0
                val rowMaxHeight = row.maxOfOrNull { it.height } ?: 0
                row.forEach { placeable ->
                    placeable.place(x, y)
                    x += placeable.width
                }
                y += rowMaxHeight
            }
        }
    }
}

// ----------------------------------------------------
// HADITH SCREEN
// ----------------------------------------------------
@Composable
fun HadithScreen(viewModel: ImaanHubViewModel) {
    val searchStr by viewModel.hadithSearchQuery.collectAsStateWithLifecycle()
    val selectedBook by viewModel.selectedHadithBook.collectAsStateWithLifecycle()
    
    val books = listOf("All", "Sahih Bukhari", "Sahih Muslim", "Riyad-us-Saliheen")

    val filteredHadiths = remember(searchStr, selectedBook) {
        IslamicData.hadiths.filter {
            (selectedBook == "All" || it.book == selectedBook) &&
                    (searchStr.isBlank() || it.english.contains(searchStr, ignoreCase = true) ||
                            it.chapter.contains(searchStr, ignoreCase = true) ||
                            it.bangla.contains(searchStr))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Hadith Collection",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        OutlinedTextField(
            value = searchStr,
            onValueChange = { viewModel.setHadithSearchQuery(it) },
            placeholder = { Text("Search hadith chapter, content...") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("hadith_search"),
            shape = RoundedCornerShape(16.dp)
        )

        // Book selector chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(books) { book ->
                val isSelected = selectedBook == book
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectHadithBook(book) },
                    label = { Text(book) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredHadiths) { hadith ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = hadith.book,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = hadith.reference,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }

                        Text(
                            text = "Chapter: ${hadith.chapter}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = hadith.arabic,
                            style = MaterialTheme.typography.titleLarge,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.primary
                        )

                        Text(
                            text = "Narrated by ${hadith.narrator}:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )

                        Text(
                            text = "English: ${hadith.english}",
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Text(
                            text = "বাংলা: ${hadith.bangla}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// PRAYER / QIBLA COMPASS SCREEN
// ----------------------------------------------------
@Composable
fun PrayerScreen(viewModel: ImaanHubViewModel, onNavigateToSub: (String) -> Unit) {
    val rotation by viewModel.qiblaRotation.collectAsStateWithLifecycle()
    val azanEnabled by viewModel.isAzanEnabled.collectAsStateWithLifecycle()
    val currentLang by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = t("Prayer & Qibla Guide", "নামাজ ও কিবলা গাইড", currentLang),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // 3D/Interactive Qibla Compass
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = t("Qibla Compass Guide", "কিবলা কম্পাস নির্দেশিকা", currentLang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .testTag("qibla_compass"),
                    contentAlignment = Alignment.Center
                ) {
                    // Outer Compass Ring
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = Color(0xFFD4AF37),
                            style = Stroke(width = 4.dp.toPx())
                        )
                    }

                    // Rotating Arrow pointing Mecca
                    Icon(
                        imageVector = Icons.Default.Navigation,
                        contentDescription = "Compass Arrow",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(90.dp)
                            .rotate(rotation)
                    )

                    // Center Mecca Indicator Symbol
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Mecca",
                        tint = Color(0xFFD4AF37),
                        modifier = Modifier
                            .size(24.dp)
                            .align(Alignment.Center)
                    )
                }

                Text(
                    text = t(
                        "Keep device flat. Mecca bearing approx: ${rotation.toInt()}° North-East",
                        "ডিভাইসটি সমান্তরাল রাখুন। মক্কার দিক প্রায়: ${translateNumber(rotation.toInt().toString(), currentLang)}° উত্তর-পূর্ব",
                        currentLang
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }

        // Quick Guides features (Wudu, Salah, Nafl)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { onNavigateToSub("hajj") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Map, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(t("Hajj Checklist", "হজ চেকলিস্ট", currentLang))
            }

            Button(
                onClick = { onNavigateToSub("mosque") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(imageVector = Icons.Default.Place, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(t("Find Mosques", "মসজিদ খুঁজুন", currentLang))
            }
        }

        // Daily Azan Alerts management list
        Text(
            text = t("Azan Notification Settings", "আজান নোটিফিকেশন সেটিংস", currentLang),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                val prayers = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
                prayers.forEach { prayer ->
                    val isEnabled = azanEnabled[prayer] ?: true
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = translatePrayerName(prayer, currentLang), fontWeight = FontWeight.Bold)
                        Switch(
                            checked = isEnabled,
                            onCheckedChange = { viewModel.toggleAzan(prayer) }
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// DIGITAL TASBIH SCREEN
// ----------------------------------------------------
@Composable
fun TasbihScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val count by viewModel.tasbihCount.collectAsStateWithLifecycle()
    val selectedDhikr by viewModel.selectedDhikr.collectAsStateWithLifecycle()
    val listHistory by viewModel.tasbihHistory.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Digital Tasbih",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Dhikr selection dropdown list
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(viewModel.dhikrList) { dhikr ->
                val isSelected = selectedDhikr == dhikr
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectDhikr(dhikr) },
                    label = { Text(dhikr) }
                )
            }
        }

        // Big Digital counter circle card
        Card(
            modifier = Modifier
                .size(240.dp)
                .clickable { viewModel.incrementTasbih() }
                .testTag("tasbih_circle"),
            shape = CircleShape,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "DHIKR COUNT",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Text(
                        text = count.toString(),
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Text(
                        text = "TAP TO COUNT",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.8f),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            OutlinedButton(onClick = { viewModel.resetTasbih() }) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Save & Reset")
            }
        }

        // History logs
        Text(
            text = "Dhikr Session History",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Left
        )

        Card(
            modifier = Modifier.fillMaxWidth().weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            if (listHistory.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No sessions recorded yet.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
            } else {
                LazyColumn(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(listHistory) { hist ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = hist.dhikrName, fontWeight = FontWeight.SemiBold)
                            Text(text = "${hist.count} times", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// HISNUL MUSLIM DUAS SCREEN
// ----------------------------------------------------
@Composable
fun DuasScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val searchStr by viewModel.duaSearchQuery.collectAsStateWithLifecycle()
    val activeCategory by viewModel.selectedDuaCategory.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    val categories = listOf("Morning", "Evening", "Daily", "Hisnul Muslim")

    val filteredDuas = remember(searchStr, activeCategory) {
        IslamicData.duas.filter {
            it.category == activeCategory &&
                    (searchStr.isBlank() || it.title.contains(searchStr, ignoreCase = true) ||
                            it.english.contains(searchStr, ignoreCase = true) ||
                            it.bangla.contains(searchStr))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = t("Supplications & Duas", "দোয়া ও প্রার্থনা", currentLanguage),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        OutlinedTextField(
            value = searchStr,
            onValueChange = { viewModel.setDuaSearchQuery(it) },
            placeholder = { Text(t("Search morning, evening supplications...", "সকাল-সন্ধ্যার দোয়া খুঁজুন...", currentLanguage)) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("dua_search"),
            shape = RoundedCornerShape(16.dp)
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories) { category ->
                val isSelected = activeCategory == category
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectDuaCategory(category) },
                    label = { Text(translateDuaCategory(category, currentLanguage)) }
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredDuas) { dua ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = translateDuaTitle(dua.title, currentLanguage),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            IconButton(onClick = {
                                viewModel.toggleBookmark("dua", dua.title, dua.category, dua.id.toString())
                            }) {
                                val isBookmarked by viewModel.isBookmarked("dua", dua.id.toString()).collectAsStateWithLifecycle()
                                Icon(
                                    imageVector = if (isBookmarked) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }

                        Text(
                            text = dua.arabic,
                            style = MaterialTheme.typography.titleLarge,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.primary
                        )

                        val translit = if (currentLanguage == "Bangla" && dua.transliterationBn.isNotBlank()) {
                            dua.transliterationBn
                        } else {
                            dua.transliteration
                        }

                        Text(
                            text = "${t("Transliteration", "উচ্চারণ", currentLanguage)}: $translit",
                            style = MaterialTheme.typography.bodyMedium,
                            fontStyle = FontStyle.Italic
                        )

                        Text(
                            text = "${t("Translation", "অর্থ", currentLanguage)}: ${t(dua.english, dua.bangla, currentLanguage)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Show secondary translation in smaller text
                        Text(
                            text = if (currentLanguage == "Bangla") "${t("English", "ইংরেজী", currentLanguage)}: ${dua.english}" else "${t("Bangla", "বাংলা", currentLanguage)}: ${dua.bangla}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// ISLAMIC QUIZ SCREEN
// ----------------------------------------------------
@Composable
fun QuizScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val currentIndex by viewModel.currentQuestionIndex.collectAsStateWithLifecycle()
    val score by viewModel.quizScore.collectAsStateWithLifecycle()
    val selectedAnswer by viewModel.quizSelectedAnswer.collectAsStateWithLifecycle()
    val isAnswered by viewModel.isQuizAnswered.collectAsStateWithLifecycle()

    val currentQuestion = IslamicData.quizQuestions[currentIndex]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Islamic Trivia Quiz",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Visual progress tracker
        LinearProgressIndicator(
            progress = { (currentIndex + 1).toFloat() / IslamicData.quizQuestions.size },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.primaryContainer
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Question ${currentIndex + 1} of ${IslamicData.quizQuestions.size}", fontWeight = FontWeight.Bold)
            Text(text = "Score: $score", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                    text = currentQuestion.question,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // Render options
                currentQuestion.options.forEachIndexed { idx, opt ->
                    val color = when {
                        isAnswered && idx == currentQuestion.correctAnswerIndex -> Color(0xFF2E7D32)
                        isAnswered && idx == selectedAnswer && idx != currentQuestion.correctAnswerIndex -> Color(0xFFC62828)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                    Button(
                        onClick = { viewModel.selectQuizAnswer(idx) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = color),
                        enabled = !isAnswered
                    ) {
                        Text(
                            text = opt,
                            color = if (isAnswered) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Answer explanation block
        if (isAnswered) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Explanation:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = currentQuestion.explanation,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(
                        onClick = { viewModel.nextQuizQuestion() },
                        modifier = Modifier.align(Alignment.End),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Next Question")
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// ZAKAT CALCULATOR SCREEN
// ----------------------------------------------------
@Composable
fun ZakatScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val cash by viewModel.zakatCash.collectAsStateWithLifecycle()
    val gold by viewModel.zakatGold.collectAsStateWithLifecycle()
    val silver by viewModel.zakatSilver.collectAsStateWithLifecycle()
    val otherAssets by viewModel.zakatAssets.collectAsStateWithLifecycle()
    val liabilities by viewModel.zakatLiabilities.collectAsStateWithLifecycle()
    val result by viewModel.zakatResult.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Zakat Calculator",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Calculate Your Wealth & Zakat",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = cash,
                    onValueChange = { viewModel.updateZakatCash(it) },
                    label = { Text("Cash / Bank balance") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = gold,
                    onValueChange = { viewModel.updateZakatGold(it) },
                    label = { Text("Gold value (grams)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = silver,
                    onValueChange = { viewModel.updateZakatSilver(it) },
                    label = { Text("Silver value (grams)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = otherAssets,
                    onValueChange = { viewModel.updateZakatAssets(it) },
                    label = { Text("Other investments/business assets") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = liabilities,
                    onValueChange = { viewModel.updateZakatLiabilities(it) },
                    label = { Text("Liabilities / Debts") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Zakat Due Output Premium Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Zakat Due (2.5%):",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White.copy(alpha = 0.8f)
                )
                Text(
                    text = String.format("$%.2f", result),
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.tertiary,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Nisab threshold for 85g gold is assumed approx: $85,000",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }
        }
    }
}

// ----------------------------------------------------
// MOSQUE FINDER SCREEN
// ----------------------------------------------------
@Composable
fun MosqueFinderScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val searchStr by viewModel.mosqueSearchQuery.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    val filtered = remember(searchStr) {
        viewModel.simulatedMosques.filter {
            searchStr.isBlank() || it.name.contains(searchStr, ignoreCase = true) ||
                    it.address.contains(searchStr, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = t("Nearby Mosques", "নিকটবর্তী মসজিদসমূহ", currentLanguage),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        OutlinedTextField(
            value = searchStr,
            onValueChange = { viewModel.setMosqueSearchQuery(it) },
            placeholder = { Text(t("Search mosque name, area...", "মসজিদের নাম, এলাকা খুঁজুন...", currentLanguage)) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filtered) { mosque ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = mosque.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "${translateNumber(mosque.distanceKm.toString(), currentLanguage)} ${t("km", "কিমি", currentLanguage)}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }

                        Text(
                            text = mosque.address,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )

                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                        // Next congregation times info
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = translatePrayerName("Fajr", currentLanguage), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(text = translateNumber(mosque.fajr, currentLanguage), style = MaterialTheme.typography.bodyMedium)
                            }
                            Column {
                                Text(text = translatePrayerName("Dhuhr", currentLanguage), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(text = translateNumber(mosque.dhuhr, currentLanguage), style = MaterialTheme.typography.bodyMedium)
                            }
                            Column {
                                Text(text = translatePrayerName("Asr", currentLanguage), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(text = translateNumber(mosque.asr, currentLanguage), style = MaterialTheme.typography.bodyMedium)
                            }
                            Column {
                                Text(text = translatePrayerName("Maghrib", currentLanguage), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(text = translateNumber(mosque.maghrib, currentLanguage), style = MaterialTheme.typography.bodyMedium)
                            }
                            Column {
                                Text(text = translatePrayerName("Isha", currentLanguage), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(text = translateNumber(mosque.isha, currentLanguage), style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// HAJJ GUIDE SCREEN
// ----------------------------------------------------
@Composable
fun HajjGuideScreen(onBack: () -> Unit) {
    var step by remember { mutableStateOf(1) }

    val steps = listOf(
        Pair("1. Ihram & Niyyah", "Wear clean white garments and declare your formal intention to perform pilgrimage upon entering Miqat boundaries."),
        Pair("2. Tawaf al-Qudum", "Circle the holy Kaaba counter-clockwise 7 times upon arrival at Masjid al-Haram in Mecca."),
        Pair("3. Sa'iy (Safa & Marwah)", "Walk and run gently 7 times between Safa and Marwah mountains to commemorate Hagar's search for water."),
        Pair("4. Camp at Mina", "Spend the day and night praying in Mina's camp city to prepare spiritually for Arafat."),
        Pair("5. Day of Arafat", "The core pillar of Hajj. Spend afternoon praying intensely and seeking forgiveness at Mount Arafat."),
        Pair("6. Muzdalifah Camp", "Spend night under open sky gathering small pebbles for the upcoming staling rituals.")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Hajj Step-by-Step Guide",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Checklist timeline layout
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(steps) { p ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = p.first,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = p.second,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// ISLAMIC NOTES JOURNAL SCREEN
// ----------------------------------------------------
@Composable
fun NotesScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val listNotes by viewModel.notes.collectAsStateWithLifecycle()
    var noteTitle by remember { mutableStateOf("") }
    var noteContent by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Islamic Spiritual Notes",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = "Add Reflection Note", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(
                    value = noteTitle,
                    onValueChange = { noteTitle = it },
                    label = { Text("Note Title") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = noteContent,
                    onValueChange = { noteContent = it },
                    label = { Text("Write your reflections, Quran goals...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                )
                Button(
                    onClick = {
                        viewModel.saveNote(noteTitle, noteContent)
                        noteTitle = ""
                        noteContent = ""
                    },
                    modifier = Modifier.align(Alignment.End),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Save Note")
                }
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(listNotes) { note ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = note.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            IconButton(onClick = { viewModel.deleteNote(note) }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                            }
                        }
                        Text(
                            text = note.content,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// ISLAMIC BOOKS READERS SCREEN
// ----------------------------------------------------
@Composable
fun IslamicBooksScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val selectedId by viewModel.selectedBookId.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                if (selectedId != null) {
                    viewModel.selectBook(null)
                } else {
                    onBack()
                }
            }) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = if (selectedId != null) t("Reading Book", "বই পড়া", currentLanguage) else t("Islamic Books Library", "ইসলামিক বই লাইব্রেরি", currentLanguage),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (selectedId == null) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(IslamicData.books) { book ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectBook(book.id) },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = t(book.title, book.titleBn, currentLanguage),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "${t("By", "লেখক:", currentLanguage)} ${t(book.author, book.authorBn, currentLanguage)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = t(book.description, book.descriptionBn, currentLanguage),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        } else {
            val currentBook = IslamicData.books.firstOrNull { it.id == selectedId }
            if (currentBook != null) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = t(currentBook.title, currentBook.titleBn, currentLanguage),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${t("Author", "লেখক", currentLanguage)}: ${t(currentBook.author, currentBook.authorBn, currentLanguage)}",
                        fontWeight = FontWeight.Bold
                    )
                    
                    Text(
                        text = t("Chapters List:", "অধ্যায়ের তালিকা:", currentLanguage),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        val chapters = if (currentLanguage == "Bangla" && currentBook.chaptersBn.isNotEmpty()) {
                            currentBook.chaptersBn
                        } else {
                            currentBook.chapters
                        }
                        LazyColumn(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(chapters) { chap ->
                                Text(text = "• $chap", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// SETTINGS SCREEN
// ----------------------------------------------------
@Composable
fun SettingsScreen(viewModel: ImaanHubViewModel, onNavigateToSub: (String) -> Unit) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val fontSizeMultiplier by viewModel.fontSizeMultiplier.collectAsStateWithLifecycle()
    val selectedFont by viewModel.selectedArabicFont.collectAsStateWithLifecycle()
    val currentLang by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = t("ImaanHub Companion Settings", "ঈমানহাব সেটিংস", currentLang),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // General Info
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Face, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                }
                Text(
                    text = t("ImaanHub: Your Complete Companion", "ঈমানহাব: আপনার সম্পূর্ণ সাথী", currentLang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Mizan islam",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                    Text(
                        text = "Powered by Al dawah Islamic official",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Normal,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                Text(
                    text = t("Version 1.0 (Stable Premium build)", "ভার্সন ১.০ (স্থিতিশীল প্রিমিয়াম সংস্করণ)", currentLang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }

        // Settings items
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = t("Preferences Configuration", "পছন্দসমূহ কনফিগারেশন", currentLang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // App Theme Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = t("App Theme (Dark Mode)", "অ্যাপ থিম (ডার্ক মোড)", currentLang), fontWeight = FontWeight.SemiBold)
                    Switch(checked = isDarkTheme, onCheckedChange = { viewModel.toggleTheme() })
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                // Font size multiplier
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = t("Reading Text Size", "পড়ার লেখার সাইজ", currentLang), fontWeight = FontWeight.SemiBold)
                    Row {
                        FilterChip(
                            selected = fontSizeMultiplier == 0.8f,
                            onClick = { viewModel.setFontSizeMultiplier(0.8f) },
                            label = { Text(t("Small", "ছোট", currentLang)) }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        FilterChip(
                            selected = fontSizeMultiplier == 1.0f,
                            onClick = { viewModel.setFontSizeMultiplier(1.0f) },
                            label = { Text(t("Medium", "মাঝারি", currentLang)) }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        FilterChip(
                            selected = fontSizeMultiplier == 1.2f,
                            onClick = { viewModel.setFontSizeMultiplier(1.2f) },
                            label = { Text(t("Large", "বড়", currentLang)) }
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                // Translation Language Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = t("Translation Language", "অনুবাদের ভাষা", currentLang), fontWeight = FontWeight.SemiBold)
                    Row {
                        FilterChip(
                            selected = currentLang == "English",
                            onClick = { viewModel.selectLanguage("English") },
                            label = { Text("English") }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        FilterChip(
                            selected = currentLang == "Bangla",
                            onClick = { viewModel.selectLanguage("Bangla") },
                            label = { Text("বাংলা") }
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                // Font style selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = t("Arabic Font Style", "আরবি ফন্ট স্টাইল", currentLang), fontWeight = FontWeight.SemiBold)
                    Text(
                        text = selectedFont,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable {
                            val nextFont = if (selectedFont == "KFGQPC Uthman Taha") "Indopak Traditional" else "KFGQPC Uthman Taha"
                            viewModel.selectArabicFont(nextFont)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SplashScreen() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_splash_bg_1784354799408),
            contentDescription = "Splash Screen",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.2f))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 48.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(
                color = Color(0xFFE5C158),
                strokeWidth = 3.dp,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("splash_loader")
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "Loading...",
                color = Color.White.copy(alpha = 0.8f),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            Text(
                text = "Powered by",
                color = Color.White.copy(alpha = 0.5f),
                style = MaterialTheme.typography.labelMedium,
                letterSpacing = 1.sp
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = "Al dawah Islamic official",
                color = Color(0xFFE5C158),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

// ----------------------------------------------------
// HAFEZI QURAN COMPOSABLE SCREEN & PAGINATOR
// ----------------------------------------------------
data class HafeziLine(
    val text: String,
    val ayahsInLine: List<Int>
)

data class HafeziPage(
    val pageNumber: Int,
    val lines: List<HafeziLine>
)

fun toArabicDigits(numStr: String): String {
    return numStr.map {
        when (it) {
            '0' -> '٠'
            '1' -> '١'
            '2' -> '٢'
            '3' -> '٣'
            '4' -> '٤'
            '5' -> '٥'
            '6' -> '٦'
            '7' -> '٧'
            '8' -> '٨'
            '9' -> '٩'
            else -> it
        }
    }.joinToString("")
}

fun paginateSurahForHafezi(surah: Surah, wordsPerLine: Int = 6): List<HafeziPage> {
    val tokens = mutableListOf<Pair<String, Int>>()
    
    surah.ayahs.forEach { ayah ->
        val words = ayah.arabic.split("\\s+".toRegex()).filter { it.isNotBlank() }
        words.forEach { word ->
            tokens.add(Pair(word, ayah.numberInSurah))
        }
        tokens.add(Pair(" ۝${toArabicDigits(ayah.numberInSurah.toString())} ", ayah.numberInSurah))
    }
    
    val lines = mutableListOf<HafeziLine>()
    var currentLineTokens = mutableListOf<String>()
    var currentLineAyahs = mutableSetOf<Int>()
    
    tokens.forEach { (token, ayahNum) ->
        currentLineTokens.add(token)
        currentLineAyahs.add(ayahNum)
        if (currentLineTokens.size >= wordsPerLine) {
            lines.add(HafeziLine(currentLineTokens.joinToString(" "), currentLineAyahs.toList()))
            currentLineTokens = mutableListOf()
            currentLineAyahs = mutableSetOf()
        }
    }
    
    if (currentLineTokens.isNotEmpty()) {
        lines.add(HafeziLine(currentLineTokens.joinToString(" "), currentLineAyahs.toList()))
    }
    
    val pages = mutableListOf<HafeziPage>()
    var pageNo = 1
    for (i in lines.indices step 15) {
        val pageLines = lines.subList(i, minOf(i + 15, lines.size))
        pages.add(HafeziPage(pageNo++, pageLines))
    }
    
    return pages
}

@Composable
fun HafeziQuranScreen(viewModel: ImaanHubViewModel, onBack: () -> Unit) {
    val currentLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    
    var selectedSurah by remember { mutableStateOf<Surah?>(null) }
    var currentPageIndex by remember { mutableIntStateOf(0) }
    
    var arabicFontSize by remember { mutableFloatStateOf(20f) }
    var showTranslation by remember { mutableStateOf(false) }

    val hafeziBookmark = remember(bookmarks) {
        bookmarks.firstOrNull { it.type == "hafezi_quran" }
    }

    if (selectedSurah == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = t("Hafezi Quran", "হাফেজী কুরআন", currentLanguage),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (hafeziBookmark != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = t("Last Read Page", "সর্বশেষ পড়া পাতা", currentLanguage),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = hafeziBookmark.title + " - " + hafeziBookmark.subtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        
                        Button(
                            onClick = {
                                val parts = hafeziBookmark.referenceId.split("_")
                                if (parts.size == 2) {
                                    val surahNum = parts[0].toIntOrNull() ?: 1
                                    val pageIdx = parts[1].toIntOrNull() ?: 0
                                    val found = IslamicData.surahs.find { it.number == surahNum }
                                    if (found != null) {
                                        selectedSurah = found
                                        currentPageIndex = pageIdx
                                    }
                                }
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(t("Continue", "পড়া চালিয়ে যান", currentLanguage))
                        }
                    }
                }
            }

            Text(
                text = t("Select Surah to Memorize/Read", "মুখস্থ বা তিলাওয়াত করতে সূরা সিলেক্ট করুন", currentLanguage),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(IslamicData.surahs) { surah ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedSurah = surah
                                currentPageIndex = 0
                            },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            MaterialTheme.colorScheme.primaryContainer,
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = translateNumber(surah.number.toString(), currentLanguage),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Column {
                                    Text(
                                        text = t(surah.englishName, surah.banglaName, currentLanguage),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${translateNumber(surah.numberOfAyahs.toString(), currentLanguage)} ${t("Verses", "আয়াত", currentLanguage)} • ${translateRevelationType(surah.revelationType, currentLanguage)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                            }
                            Text(
                                text = surah.name,
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    } else {
        val surah = selectedSurah!!
        val pages = remember(surah) { paginateSurahForHafezi(surah) }
        val page = pages.getOrElse(currentPageIndex) { pages.firstOrNull() ?: HafeziPage(1, emptyList()) }

        val isBookmarkedFlow = remember(surah.number, currentPageIndex) {
            viewModel.isBookmarked("hafezi_quran", "${surah.number}_$currentPageIndex")
        }
        val isBookmarked by isBookmarkedFlow.collectAsStateWithLifecycle(initialValue = false)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedSurah = null }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Column {
                        Text(
                            text = t(surah.englishName, surah.banglaName, currentLanguage),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = t("Hafezi Layout (15 Lines)", "হাফেজী লেআউট (১৫ লাইন)", currentLanguage),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }

                IconButton(onClick = {
                    viewModel.toggleBookmark(
                        type = "hafezi_quran",
                        title = t(surah.englishName, surah.banglaName, currentLanguage),
                        subtitle = t("Page ${page.pageNumber}", "পৃষ্ঠা ${translateNumber(page.pageNumber.toString(), currentLanguage)}", currentLanguage),
                        refId = "${surah.number}_$currentPageIndex"
                    )
                }) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Bookmark Page",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFAF2)),
                border = BorderStroke(2.dp, Color(0xFFD4AF37).copy(alpha = 0.8f)),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = t(surah.englishName, surah.banglaName, currentLanguage),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B7355)
                        )
                        Text(
                            text = t("Hafezi Quran", "হাফেজী কুরআন", currentLanguage),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD4AF37)
                        )
                        Text(
                            text = t("Page ${page.pageNumber}", "পৃষ্ঠা ${translateNumber(page.pageNumber.toString(), currentLanguage)}", currentLanguage),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B7355)
                        )
                    }

                    HorizontalDivider(color = Color(0xFFD4AF37).copy(alpha = 0.3f), thickness = 1.dp)

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalArrangement = Arrangement.SpaceEvenly,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        for (i in 0 until 15) {
                            if (i < page.lines.size) {
                                val line = page.lines[i]
                                Text(
                                    text = line.text,
                                    style = androidx.compose.ui.text.TextStyle(
                                        fontFamily = FontFamily.Serif,
                                        fontSize = arabicFontSize.sp,
                                        textAlign = TextAlign.Center,
                                        textDirection = androidx.compose.ui.text.style.TextDirection.Rtl,
                                        color = Color(0xFF1C1C1C),
                                        fontWeight = FontWeight.Medium
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 4.dp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            } else {
                                Text(
                                    text = "۩ ۞ ۩",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFD4AF37).copy(alpha = 0.25f),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = Color(0xFFD4AF37).copy(alpha = 0.3f), thickness = 1.dp)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = t("Juz ${surah.number}", "পারা ${translateNumber(surah.number.toString(), currentLanguage)}", currentLanguage),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B7355)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { if (currentPageIndex > 0) currentPageIndex-- },
                    enabled = currentPageIndex > 0
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Page")
                }

                Text(
                    text = "${translateNumber((currentPageIndex + 1).toString(), currentLanguage)} / ${translateNumber(pages.size.toString(), currentLanguage)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )

                IconButton(
                    onClick = { if (currentPageIndex < pages.size - 1) currentPageIndex++ },
                    enabled = currentPageIndex < pages.size - 1
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Page")
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = t("Arabic Text Size", "আরবি লেখা সাইজ", currentLanguage),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = translateNumber(arabicFontSize.toInt().toString(), currentLanguage),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Slider(
                        value = arabicFontSize,
                        onValueChange = { arabicFontSize = it },
                        valueRange = 16f..26f,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = t("Show Bengali Translation", "বাংলা অনুবাদ দেখান", currentLanguage),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                        Switch(
                            checked = showTranslation,
                            onCheckedChange = { showTranslation = it }
                        )
                    }
                }
            }

            if (showTranslation) {
                val currentLineAyahNumbers = remember(page) {
                    page.lines.flatMap { it.ayahsInLine }.distinct()
                }
                
                val currentPageAyahs = remember(surah, currentLineAyahNumbers) {
                    surah.ayahs.filter { it.numberInSurah in currentLineAyahNumbers }
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(currentPageAyahs) { ayah ->
                            Column(
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = t("Ayah ${ayah.numberInSurah}", "আয়াত ${translateNumber(ayah.numberInSurah.toString(), currentLanguage)}", currentLanguage),
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Text(
                                    text = ayah.arabic,
                                    style = androidx.compose.ui.text.TextStyle(
                                        fontFamily = FontFamily.Serif,
                                        fontSize = 18.sp,
                                        textDirection = androidx.compose.ui.text.style.TextDirection.Rtl
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    text = t(ayah.english, ayah.bangla, currentLanguage),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                )
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                        }
                    }
                }
            }
        }
    }
}
